[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$TargetUrl,
    [string]$Path = '/',
    [ValidateRange(1, 1000)][int]$Attempts = 20,
    [ValidateRange(1, 300)][int]$TimeoutSeconds = 10,
    [string]$RunId,
    [switch]$SkipCertificateCheck
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$kitRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $kitRoot 'Common\TestHelpers.ps1')
if (-not $RunId) { $RunId = New-TestRunId }
$metadata = [ordered]@{ TestCaseId='TC-02'; TestName='TLS 1.3 support'; CoverageCategory='A'; CveReference=(Get-NotApplicableReference 'protocol capability test') }
try {
    $baseUri = Resolve-SafeTargetUri -TargetUrl $TargetUrl
    $uri = Join-SafeTargetUri -BaseUri $baseUri -Path $Path
}
catch { throw "TC-02 target validation failed: $($_.Exception.Message)" }
$resultDirectory = New-ResultDirectory -RunId $RunId -TestCaseId $metadata.TestCaseId
if ($SkipCertificateCheck) { Write-Warning 'TLS certificate validation is being bypassed for this run only; TC-02 cannot pass its certificate criterion.' }
$started = [datetime]::UtcNow
$samples = New-Object Collections.ArrayList
$tlsResults = New-Object Collections.ArrayList
$nativeCapability = $true
$localCapabilityReason = $null

for ($i = 1; $i -le $Attempts; $i++) {
    $tls = Get-TlsProbe -TargetUri $uri -TimeoutSeconds $TimeoutSeconds -SkipCertificateCheck:$SkipCertificateCheck -RequestTls13
    if (-not $tls.CapabilityAvailable -or (-not $tls.Success -and $tls.ErrorMessage -match 'not supported|not available|PlatformNotSupported')) {
        $nativeCapability = $false
        $localCapabilityReason = $tls.ErrorMessage
        break
    }
    $http = Invoke-SafeHttpRequest -TargetUri $uri -RunId $RunId -TestCaseId $metadata.TestCaseId -ProbeId ('TLS13-' + $i) -TimeoutSeconds $TimeoutSeconds -SkipCertificateCheck:$SkipCertificateCheck
    if (-not $tls.Success) { $http.Success = $false }
    $null = $tlsResults.Add($tls)
    $null = $samples.Add((New-SampleRecord -Sequence $i -HttpResult $http -TlsResult $tls -TargetUri $uri -RunId $RunId -TestCaseId $metadata.TestCaseId -ProbeId 'TLS13'))
}

$fallbackUsed = $false
$curlCapability = $null
if (-not $nativeCapability) {
    $curlCapability = Get-CurlTls13Capability
    if ($curlCapability.Available) {
        $fallbackUsed = $true
        for ($i = 1; $i -le $Attempts; $i++) {
            $correlation = New-CorrelationId -RunId $RunId -TestCaseId $metadata.TestCaseId -ProbeId ('CURL-TLS13-' + $i)
            $attemptStart = [datetime]::UtcNow
            $watch = [Diagnostics.Stopwatch]::StartNew()
            $curlArgs = @('-sS', '-o', 'NUL', '--connect-timeout', [string]$TimeoutSeconds, '--max-time', [string]$TimeoutSeconds, '--max-redirs', '0', '--proto', '=https', '--tlsv1.3', '--tls-max', '1.3')
            if ($SkipCertificateCheck) { $curlArgs += '--insecure' }
            # curl does not expose a portable ssl_version write-out variable.
            # A successful transfer proves TLS 1.3 because both protocol bounds
            # are pinned to 1.3 above; only the supported HTTP status is emitted.
            $curlArgs += @('-H', "X-EasyBuy-Test-Run: $RunId", '-H', 'X-EasyBuy-Test-Case: TC-02', '-H', "X-EasyBuy-Correlation-ID: $correlation", '-w', '%{http_code}', $uri.AbsoluteUri)
            $output = @(& $curlCapability.CommandPath @curlArgs 2>&1)
            $exitCode = $LASTEXITCODE
            $watch.Stop()
            $status = $null
            $protocol = $null
            $outputText = ($output -join ' ').Trim()
            if ($exitCode -eq 0 -and $outputText -match '(?<!\d)(\d{3})$') {
                $status = [int]$matches[1]
                $protocol = 'TLSv1.3 (curl enforced)'
            }
            if ($exitCode -ne 0 -and ($exitCode -eq 2 -or $exitCode -eq 4 -or $exitCode -eq 35 -or $outputText -match '(?i)TLS 1\.3.*(?:not supported|disabled|unavailable)|(?:unsupported|not supported).*TLS|Schannel.*(?:disabled|not supported)|built without.*TLS')) {
                $localCapabilityReason = "curl.exe could not establish forced TLS 1.3 with its current SSL backend; local capability cannot be distinguished from target negotiation: $outputText"
                $fallbackUsed = $false
                break
            }
            $isSuccess = $exitCode -eq 0 -and $null -ne $status -and $status -ge 200 -and $status -lt 400 -and $protocol -match 'TLSv1\.3|Tls13'
            $http = [pscustomobject]@{
                TimestampUtc = Get-UtcTimestamp $attemptStart; EndTimeUtc = Get-UtcTimestamp; CorrelationId = $correlation
                StatusCode = $status; TransportOutcome = if ($exitCode -eq 0) { 'HTTP_RESPONSE' } else { 'CURL_ERROR' }
                LatencyMs = [Math]::Round($watch.Elapsed.TotalMilliseconds, 3); Success = $isSuccess
                ErrorCategory = if ($exitCode -eq 0) { $null } else { 'curl.exe exit ' + $exitCode }
                ErrorMessage = if ($exitCode -eq 0) { $null } else { $outputText }
            }
            $certificateState = if ($SkipCertificateCheck) { $false } elseif ($exitCode -eq 0) { $true } elseif ($exitCode -eq 60) { $false } else { $null }
            $tls = [pscustomobject]@{
                TlsProtocol=$protocol; CertificateThumbprint=$null; CertificateSerialNumber=$null
                CertificateNotBeforeUtc=$null; CertificateNotAfterUtc=$null; CertificateValidationSucceeded=$certificateState
            }
            $null = $samples.Add((New-SampleRecord -Sequence $i -HttpResult $http -TlsResult $tls -TargetUri $uri -RunId $RunId -TestCaseId $metadata.TestCaseId -ProbeId 'TLS13-CURL'))
        }
    }
    else {
        $localCapabilityReason = $curlCapability.Reason
    }
}

$items = @($samples)
$stats = Get-RequestStatistics -Samples $items
$protocols = @($items | ForEach-Object { $_.TlsProtocol } | Where-Object { $_ } | Sort-Object -Unique)
$allTls13 = $items.Count -eq $Attempts -and @($items | Where-Object { $_.TlsProtocol -notmatch 'Tls13|TLSv1\.3' }).Count -eq 0
$certificateFailures = @($items | Where-Object { $_.CertificateValidationSucceeded -eq $false }).Count
$localCapabilityLimited = -not $nativeCapability -and (-not $fallbackUsed -or $items.Count -ne $Attempts)
$verdict = if ($SkipCertificateCheck) {
    'INCONCLUSIVE'
} elseif ($localCapabilityLimited -or $items.Count -eq 0) {
    'INCONCLUSIVE'
} elseif ($stats.SuccessCount -eq $Attempts -and $allTls13 -and $certificateFailures -eq 0) {
    'PASS'
} else {
    'FAIL'
}
$ended = [datetime]::UtcNow
$target = Get-SanitizedTarget $uri
$firstTls = if ($tlsResults.Count -gt 0) { $tlsResults[0] } else { $null }
$record = New-ResultRecord -Values @{
    RunId=$RunId; CorrelationId=if ($items.Count -gt 0) { $items[0].CorrelationId } else { New-CorrelationId -RunId $RunId -TestCaseId $metadata.TestCaseId -ProbeId 'CAPABILITY' }
    TestCaseId=$metadata.TestCaseId; TestName=$metadata.TestName; CoverageCategory=$metadata.CoverageCategory; ProbeId='TLS13'; ProbeName='Repeated TLS 1.3 handshakes and requests'
    CveReference=$metadata.CveReference; StartTimeUtc=Get-UtcTimestamp $started; EndTimeUtc=Get-UtcTimestamp $ended; DurationMs=[Math]::Round(($ended-$started).TotalMilliseconds,3)
    SkipCertificateCheck=[bool]$SkipCertificateCheck; ManualEvidenceRequired=$false; TargetUrl=$target.TargetUrl; TargetScheme=$target.TargetScheme; TargetHost=$target.TargetHost
    TargetPort=$target.TargetPort; TargetPath=$target.TargetPath; Method='GET'; TlsProtocol=($protocols -join ', ')
    CipherSuite=if ($firstTls) { $firstTls.CipherSuite } else { $null }; CertificateSubject=if ($firstTls) { $firstTls.CertificateSubject } else { $null }
    CertificateIssuer=if ($firstTls) { $firstTls.CertificateIssuer } else { $null }; CertificateThumbprint=if ($firstTls) { $firstTls.CertificateThumbprint } else { $null }
    CertificateSerialNumber=if ($firstTls) { $firstTls.CertificateSerialNumber } else { $null }; CertificateNotBeforeUtc=if ($firstTls) { $firstTls.CertificateNotBeforeUtc } else { $null }
    CertificateNotAfterUtc=if ($firstTls) { $firstTls.CertificateNotAfterUtc } else { $null }
    CertificateValidationSucceeded=if ($SkipCertificateCheck) { $false } elseif ($items.Count -gt 0 -and $certificateFailures -eq 0) { $true } else { $false }
    RequestCount=$stats.RequestCount; SuccessCount=$stats.SuccessCount; FailureCount=$stats.FailureCount; StatusDistribution=$stats.StatusDistribution
    LatencyP50Ms=$stats.LatencyP50Ms; LatencyP95Ms=$stats.LatencyP95Ms; LatencyP99Ms=$stats.LatencyP99Ms; ThroughputRequestsPerSecond=$stats.ThroughputRequestsPerSecond
    ExpectedOutcome="$Attempts of $Attempts certificate-validating TLS 1.3 requests succeed without warning."
    ObservedOutcome="Requests=$($stats.RequestCount), successes=$($stats.SuccessCount), protocols=$($protocols -join ','), nativeCapability=$nativeCapability, curlExeFallback=$fallbackUsed."
    Verdict=$verdict; ErrorCategory=if ($localCapabilityLimited) { 'LOCAL_TLS13_CAPABILITY' } else { $null }
    ErrorMessage=if ($localCapabilityLimited) { $localCapabilityReason } else { $null }
    Notes='curl.exe is optional, invoked only by executable name after option capability detection, and any certificate bypass is scoped to that process. Certificate details are unavailable in curl fallback evidence.'
}
$null = Write-TestArtifacts -ResultDirectory $resultDirectory -Records @($record) -Samples $items -AdditionalSummary @('TLS 1.3 is negotiated at the ALB/ACM listener, not at the firewall.')
Write-Output "RESULT_DIR=$resultDirectory"
