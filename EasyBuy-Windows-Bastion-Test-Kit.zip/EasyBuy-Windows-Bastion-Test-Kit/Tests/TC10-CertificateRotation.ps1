[CmdletBinding()]
param(
    [string]$TargetUrl,
    [string]$Path = '/',
    [ValidateRange(1, 86400)][int]$DurationSeconds = 100,
    [ValidateRange(300, 60000)][int]$CadenceMilliseconds = 1000,
    [ValidateRange(1, 300)][int]$TimeoutSeconds = 5,
    [string]$RunId,
    [switch]$SkipCertificateCheck,
    [ValidateLength(1, 80)][string]$WriteEventMarker,
    [string]$MarkerFile
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$kitRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $kitRoot 'Common\TestHelpers.ps1')
if ($WriteEventMarker) {
    if (-not $MarkerFile) { throw '-MarkerFile is required with -WriteEventMarker.' }
    Write-Output (Write-EventMarker -MarkerFile $MarkerFile -Label $WriteEventMarker)
    return
}
if (-not $TargetUrl) { throw '-TargetUrl is required when running the monitor.' }
if (-not $RunId) { $RunId = New-TestRunId }
$baseUri = Resolve-SafeTargetUri -TargetUrl $TargetUrl
$uri = Join-SafeTargetUri -BaseUri $baseUri -Path $Path
$resultDirectory = New-ResultDirectory -RunId $RunId -TestCaseId 'TC-10'
$markerPath = Join-Path $resultDirectory 'operator-markers.txt'
if ($SkipCertificateCheck) { Write-Warning 'TLS certificate validation is being bypassed for this run only.' }
Write-Warning 'MONITOR ONLY: ACM certificate attachment/default switching remains a manual AWS Console action.'
Write-Host "Press M or Enter for immediate key markers, or use -WriteEventMarker with: $markerPath"
$started = [datetime]::UtcNow
$monitor = Invoke-RequestMonitor -TargetUri $uri -RunId $RunId -TestCaseId 'TC-10' -ProbeId 'CERTIFICATE-MONITOR' -DurationSeconds $DurationSeconds -CadenceMilliseconds $CadenceMilliseconds -TimeoutSeconds $TimeoutSeconds -MarkerFile $markerPath -MaxConcurrency 4 -IncludeTlsProbe -SkipCertificateCheck:$SkipCertificateCheck
$ended = [datetime]::UtcNow
$samples = @($monitor.Samples)
$stats = Get-RequestStatistics -Samples $samples
$outage = Get-OutageStatistics -Samples $samples
$target = Get-SanitizedTarget $uri
$thumbprints = @($samples | ForEach-Object { $_.CertificateThumbprint } | Where-Object { $_ } | Sort-Object -Unique)
$serials = @($samples | ForEach-Object { $_.CertificateSerialNumber } | Where-Object { $_ } | Sort-Object -Unique)
$protocols = @($samples | ForEach-Object { $_.TlsProtocol } | Where-Object { $_ } | Sort-Object -Unique)
$first = if ($samples.Count -gt 0) { $samples[0] } else { $null }
$markerText = @($monitor.Markers | ForEach-Object { $_.TimestampUtc + '=' + $_.Label }) -join '; '
$record = New-ResultRecord -Values @{
    RunId=$RunId; CorrelationId=if ($first) { $first.CorrelationId } else { New-CorrelationId -RunId $RunId -TestCaseId 'TC-10' -ProbeId 'CERTIFICATE-MONITOR' }
    TestCaseId='TC-10'; TestName='ALB ACM certificate rotation continuity'; CoverageCategory='B'; ProbeId='CERTIFICATE-MONITOR'; ProbeName='Continuous TLS and certificate monitor'
    CveReference=(Get-NotApplicableReference 'certificate lifecycle/control test'); StartTimeUtc=Get-UtcTimestamp $started; EndTimeUtc=Get-UtcTimestamp $ended; DurationMs=[Math]::Round(($ended-$started).TotalMilliseconds,3)
    SkipCertificateCheck=[bool]$SkipCertificateCheck; OperatorMarker=$markerText; ManualEvidenceRequired=$true; TargetUrl=$target.TargetUrl; TargetScheme=$target.TargetScheme
    TargetHost=$target.TargetHost; TargetPort=$target.TargetPort; TargetPath=$target.TargetPath; Method='GET'; TlsProtocol=($protocols -join ', ')
    CertificateThumbprint=if ($first) { $first.CertificateThumbprint } else { $null }; CertificateSerialNumber=if ($first) { $first.CertificateSerialNumber } else { $null }
    CertificateNotBeforeUtc=if ($first) { $first.CertificateNotBeforeUtc } else { $null }; CertificateNotAfterUtc=if ($first) { $first.CertificateNotAfterUtc } else { $null }
    CertificateValidationSucceeded=if ($SkipCertificateCheck) { $false } elseif (@($samples | Where-Object { $_.CertificateValidationSucceeded -eq $false }).Count -eq 0) { $true } else { $false }
    RequestCount=$stats.RequestCount; SuccessCount=$stats.SuccessCount; FailureCount=$stats.FailureCount; StatusDistribution=$stats.StatusDistribution
    LatencyP50Ms=$stats.LatencyP50Ms; LatencyP95Ms=$stats.LatencyP95Ms; LatencyP99Ms=$stats.LatencyP99Ms; ThroughputRequestsPerSecond=$stats.ThroughputRequestsPerSecond
    WorstConsecutiveFailures=$outage.WorstConsecutiveFailures; WorstOutageStartUtc=$outage.WorstOutageStartUtc; WorstOutageEndUtc=$outage.WorstOutageEndUtc
    WorstOutageDurationMs=$outage.WorstOutageDurationMs; MaxInterSampleGapMs=$outage.MaxInterSampleGapMs
    ExpectedOutcome='The approved ACM certificate changes at the ALB without failed client requests or a certificate validation warning.'
    ObservedOutcome="Samples=$($stats.RequestCount), failures=$($stats.FailureCount), thumbprints=$($thumbprints -join ','), serials=$($serials -join ','), worstOutageMs=$($outage.WorstOutageDurationMs)."
    Verdict='MANUAL_REQUIRED'; Notes='Use markers to separate before/during/after evidence. This client can measure continuity and certificate identity but cannot prove or perform the ACM console action; no firewall certificate is involved.'
}
$null = Write-TestArtifacts -ResultDirectory $resultDirectory -Records @($record) -Samples $samples -AdditionalSummary @(
    "Marker file: $markerPath",
    'Capture the ALB listener certificate list and ACM event timestamps alongside this run.'
)
Write-Output "RESULT_DIR=$resultDirectory"
