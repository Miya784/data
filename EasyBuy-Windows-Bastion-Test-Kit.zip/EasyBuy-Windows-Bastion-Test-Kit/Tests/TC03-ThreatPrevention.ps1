[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$TargetUrl,
    [ValidateRange(1, 300)][int]$TimeoutSeconds = 10,
    [string]$RunId,
    [switch]$SkipCertificateCheck,
    [switch]$ConfirmAuthorizedTesting
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$kitRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $kitRoot 'Common\TestHelpers.ps1')
Assert-AuthorizedTesting -AuthorizationConfirmed ([bool]$ConfirmAuthorizedTesting) -TestCaseId 'TC-03'
Write-Warning 'AUTHORIZED SECURITY TEST: inert detection payloads will be sent only to the supplied HTTPS host. PAN-OS logs are required for verdicts.'
if (-not $RunId) { $RunId = New-TestRunId }
$baseUri = Resolve-SafeTargetUri -TargetUrl $TargetUrl
$resultDirectory = New-ResultDirectory -RunId $RunId -TestCaseId 'TC-03'
if ($SkipCertificateCheck) { Write-Warning 'TLS certificate validation is being bypassed for this run only.' }
$records = New-Object Collections.ArrayList
$samples = New-Object Collections.ArrayList
$sequence = 0
foreach ($probe in @(Get-SafeSecurityProbeDefinitions -MarkerId $RunId)) {
    $sequence++
    $uri = Join-SafeTargetUri -BaseUri $baseUri -Path $probe.Path
    $http = Invoke-SafeHttpRequest -TargetUri $uri -RunId $RunId -TestCaseId 'TC-03' -ProbeId $probe.ProbeId -Method $probe.Method -Headers $probe.Headers -Body $probe.Body -ContentType $probe.ContentType -TimeoutSeconds $TimeoutSeconds -SkipCertificateCheck:$SkipCertificateCheck
    $target = Get-SanitizedTarget $uri
    $record = New-ResultRecord -Values @{
        RunId=$RunId; CorrelationId=$http.CorrelationId; TestCaseId='TC-03'; TestName='Threat Prevention signature probes'; CoverageCategory='B'
        ProbeId=$probe.ProbeId; ProbeName=$probe.ProbeName; CveReference=$probe.CveReference; AuthorizationConfirmed=$true
        SkipCertificateCheck=[bool]$SkipCertificateCheck; ManualEvidenceRequired=$true; StartTimeUtc=$http.TimestampUtc; EndTimeUtc=$http.EndTimeUtc; DurationMs=$http.LatencyMs
        TargetUrl=$target.TargetUrl; TargetScheme=$target.TargetScheme; TargetHost=$target.TargetHost; TargetPort=$target.TargetPort; TargetPath=$target.TargetPath
        Method=$probe.Method; StatusCode=$http.StatusCode; TransportOutcome=$http.TransportOutcome; RequestCount=1
        SuccessCount=if ($http.Success) { 1 } else { 0 }; FailureCount=if ($http.Success) { 0 } else { 1 }
        StatusDistribution=[ordered]@{ ([string]$(if ($null -eq $http.StatusCode) { 'NO_STATUS' } else { $http.StatusCode })) = 1 }
        LatencyP50Ms=$http.LatencyMs; LatencyP95Ms=$http.LatencyMs; LatencyP99Ms=$http.LatencyMs
        ExpectedOutcome='PAN-OS Threat and Traffic rows match the request by UTC window, tuple, rule/session, expected signature/action, and request order; at least 90% of applicable signature probes are blocked in the approved profile.'
        ObservedOutcome="Client transport=$($http.TransportOutcome), status=$($http.StatusCode). This symptom alone does not prove a firewall block."
        Verdict='MANUAL_REQUIRED'; ExpectedPaloSignatureIds=$probe.ExpectedPaloSignatureIds; ErrorCategory=$http.ErrorCategory; ErrorMessage=$http.ErrorMessage
        Notes='Detection-only payload. Match UTC time, source/destination tuple, allow-alb-to-app rule/session, expected signature, severity, action, and probe order. Custom headers are not assumed to be log fields.'
    }
    $null = $records.Add($record)
    $null = $samples.Add((New-SampleRecord -Sequence $sequence -HttpResult $http -TargetUri $uri -RunId $RunId -TestCaseId 'TC-03' -ProbeId $probe.ProbeId))
}
$null = Write-TestArtifacts -ResultDirectory $resultDirectory -Records @($records) -Samples @($samples) -AdditionalSummary @(
    'AUTHORIZATION CONFIRMED: the operator explicitly enabled security-test payloads.',
    'A reset, timeout, or ALB error is provisional. Final scoring requires PAN-OS Threat and Traffic rows matched by UTC, tuple, rule/session, signature/action, and request order.',
    'The X-EasyBuy headers are exact local/wire markers; use them externally only if an approved logging carrier was configured and validated.',
    'Only Log4Shell, Shellshock, and Struts S2-045 carry exact CVE mappings; generic probes are N/A.'
)
Write-Output "RESULT_DIR=$resultDirectory"
