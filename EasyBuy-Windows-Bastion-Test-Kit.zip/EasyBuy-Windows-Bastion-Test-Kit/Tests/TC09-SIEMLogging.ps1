[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$TargetUrl,
    [string]$Path = '/',
    [ValidateRange(1, 1000)][int]$EventCount = 3,
    [ValidateRange(1, 300)][int]$TimeoutSeconds = 10,
    [string]$RunId,
    [switch]$SkipCertificateCheck
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$kitRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $kitRoot 'Common\TestHelpers.ps1')
if (-not $RunId) { $RunId = New-TestRunId }
$baseUri = Resolve-SafeTargetUri -TargetUrl $TargetUrl
$uri = Join-SafeTargetUri -BaseUri $baseUri -Path $Path
$resultDirectory = New-ResultDirectory -RunId $RunId -TestCaseId 'TC-09'
if ($SkipCertificateCheck) { Write-Warning 'TLS certificate validation is being bypassed for this run only.' }
$started = [datetime]::UtcNow
$samples = @(Invoke-RequestBatch -TargetUri $uri -RunId $RunId -TestCaseId 'TC-09' -ProbeId 'BENIGN-ALLOW-EVENT' -SampleCount $EventCount -Concurrency 1 -TimeoutSeconds $TimeoutSeconds -SkipCertificateCheck:$SkipCertificateCheck)
$ended = [datetime]::UtcNow
$stats = Get-RequestStatistics -Samples $samples
$target = Get-SanitizedTarget $uri
$firstTimestamp = if ($samples.Count -gt 0) { $samples[0].TimestampUtc } else { 'no local sample completed' }
$record = New-ResultRecord -Values @{
    RunId=$RunId; CorrelationId=if ($samples.Count -gt 0) { $samples[0].CorrelationId } else { New-CorrelationId -RunId $RunId -TestCaseId 'TC-09' -ProbeId 'BENIGN-ALLOW-EVENT' }
    TestCaseId='TC-09'; TestName='SIEM forwarding timeliness'; CoverageCategory='B'; ProbeId='BENIGN-ALLOW-EVENT'; ProbeName='Timestamped benign allow events'
    CveReference=(Get-NotApplicableReference 'logging/control test'); StartTimeUtc=Get-UtcTimestamp $started; EndTimeUtc=Get-UtcTimestamp $ended; DurationMs=[Math]::Round(($ended-$started).TotalMilliseconds,3)
    SkipCertificateCheck=[bool]$SkipCertificateCheck; ManualEvidenceRequired=$true; TargetUrl=$target.TargetUrl; TargetScheme=$target.TargetScheme; TargetHost=$target.TargetHost
    TargetPort=$target.TargetPort; TargetPath=$target.TargetPath; Method='GET'; RequestCount=$stats.RequestCount; SuccessCount=$stats.SuccessCount; FailureCount=$stats.FailureCount
    StatusDistribution=$stats.StatusDistribution; LatencyP50Ms=$stats.LatencyP50Ms; LatencyP95Ms=$stats.LatencyP95Ms; LatencyP99Ms=$stats.LatencyP99Ms
    ThroughputRequestsPerSecond=$stats.ThroughputRequestsPerSecond; ExpectedOutcome='Every generated PAN-OS event arrives complete at the approved SIEM within 30 seconds.'
    ObservedOutcome="Generated $($stats.RequestCount) benign events beginning at $firstTimestamp. This script cannot observe SIEM receipt."
    Verdict='MANUAL_REQUIRED'; Notes='Match the local UTC window/count to PAN-OS generated time, tuple, rule/session, and action, then match those same PAN-OS fields to the SIEM event and receive time. Custom headers are not assumed to be forwarded fields.'
}
$null = Write-TestArtifacts -ResultDirectory $resultDirectory -Records @($record) -Samples $samples -AdditionalSummary @(
    'An on-site SIEM operator must match PAN-OS and SIEM fields, then verify receipt count, field completeness, and receive delay below 30 seconds.',
    'The X-EasyBuy headers are exact local/wire markers; use them in the SIEM only if explicit field extraction was configured and validated.',
    'The Bastion result proves only local event generation, not remote delivery.'
)
Write-Output "RESULT_DIR=$resultDirectory"
