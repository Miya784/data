[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$TargetUrl,
    [Parameter(Mandatory = $true)][object[]]$Rows,
    [ValidateRange(1, 300)][int]$TimeoutSeconds = 10,
    [string]$RunId,
    [switch]$SkipCertificateCheck
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$kitRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $kitRoot 'Common\TestHelpers.ps1')
if (-not $RunId) { $RunId = New-TestRunId }
$baseUri = Resolve-SafeTargetUri -TargetUrl $TargetUrl
$enabledRows = @($Rows | Where-Object { $_ -is [Collections.IDictionary] -and $_.Contains('Enabled') -and [bool]$_['Enabled'] })
if ($enabledRows.Count -eq 0) { throw 'TC-12 requires at least one explicit Enabled policy row.' }
$validatedRows = New-Object Collections.ArrayList
foreach ($row in $enabledRows) {
    foreach ($required in @('Name', 'Url', 'Method', 'ExpectedOutcome')) {
        if (-not $row.Contains($required) -or [string]::IsNullOrWhiteSpace([string]$row[$required])) { throw "TC-12 row is missing $required." }
    }
    $rowUri = Resolve-SafeTargetUri -TargetUrl ([string]$row['Url']) -ExpectedHost $baseUri.DnsSafeHost
    if ($rowUri.Scheme -ne $baseUri.Scheme -or $rowUri.Port -ne $baseUri.Port) { throw 'Every TC-12 row must keep the approved target scheme, host, and port.' }
    $method = ([string]$row['Method']).ToUpperInvariant()
    if (@('GET', 'POST', 'HEAD') -notcontains $method) { throw 'TC-12 row Method must be GET, POST, or HEAD.' }
    $null = $validatedRows.Add([pscustomobject]@{ Row=$row; Uri=$rowUri; Method=$method })
}
$resultDirectory = New-ResultDirectory -RunId $RunId -TestCaseId 'TC-12'
if ($SkipCertificateCheck) { Write-Warning 'TLS certificate validation is being bypassed for this run only.' }
$records = New-Object Collections.ArrayList
$samples = New-Object Collections.ArrayList
$sequence = 0
foreach ($item in @($validatedRows)) {
    $sequence++
    $probeId = ('POLICY-' + ([string]$item.Row['Name'] -replace '[^A-Za-z0-9_-]', '-')).ToUpperInvariant()
    $http = Invoke-SafeHttpRequest -TargetUri $item.Uri -RunId $RunId -TestCaseId 'TC-12' -ProbeId $probeId -Method $item.Method -TimeoutSeconds $TimeoutSeconds -SkipCertificateCheck:$SkipCertificateCheck
    $target = Get-SanitizedTarget $item.Uri
    $record = New-ResultRecord -Values @{
        RunId=$RunId; CorrelationId=$http.CorrelationId; TestCaseId='TC-12'; TestName='Customer-supplied stateful access-control matrix'; CoverageCategory='B'
        ProbeId=$probeId; ProbeName=[string]$item.Row['Name']; CveReference=(Get-NotApplicableReference 'access-control test'); StartTimeUtc=$http.TimestampUtc; EndTimeUtc=$http.EndTimeUtc
        DurationMs=$http.LatencyMs; SkipCertificateCheck=[bool]$SkipCertificateCheck; ManualEvidenceRequired=$true; TargetUrl=$target.TargetUrl; TargetScheme=$target.TargetScheme
        TargetHost=$target.TargetHost; TargetPort=$target.TargetPort; TargetPath=$target.TargetPath; Method=$item.Method; StatusCode=$http.StatusCode; TransportOutcome=$http.TransportOutcome
        RequestCount=1; SuccessCount=if ($http.Success) { 1 } else { 0 }; FailureCount=if ($http.Success) { 0 } else { 1 }
        StatusDistribution=[ordered]@{ ([string]$(if ($null -eq $http.StatusCode) { 'NO_STATUS' } else { $http.StatusCode })) = 1 }
        LatencyP50Ms=$http.LatencyMs; LatencyP95Ms=$http.LatencyMs; LatencyP99Ms=$http.LatencyMs; ExpectedOutcome=[string]$item.Row['ExpectedOutcome']
        ObservedOutcome="Client transport=$($http.TransportOutcome), status=$($http.StatusCode). PAN-OS rule/action evidence determines the final row result."
        Verdict='MANUAL_REQUIRED'; ErrorCategory=$http.ErrorCategory; ErrorMessage=$http.ErrorMessage
        Notes='Exactly one request was sent for this explicit row. Verify allow-alb-to-app, allow-server-egress, or deny-all-log as applicable; no target discovery is performed.'
    }
    $null = $records.Add($record)
    $null = $samples.Add((New-SampleRecord -Sequence $sequence -HttpResult $http -TargetUri $item.Uri -RunId $RunId -TestCaseId 'TC-12' -ProbeId $probeId))
}
$null = Write-TestArtifacts -ResultDirectory $resultDirectory -Records @($records) -Samples @($samples) -AdditionalSummary @(
    'PAN-OS Traffic logs must confirm the expected rule and action for every row.',
    'The script did not add targets, ports, paths, or matrix rows.'
)
Write-Output "RESULT_DIR=$resultDirectory"
