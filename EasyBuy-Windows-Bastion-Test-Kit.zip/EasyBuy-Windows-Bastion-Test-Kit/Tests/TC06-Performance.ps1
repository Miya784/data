[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$TargetUrl,
    [string]$Path = '/',
    [Parameter(Mandatory = $true)][ValidateSet('Baseline', 'Inline')][string]$Phase,
    [ValidateRange(0, 10000)][int]$WarmupCount = 20,
    [ValidateRange(1, 1000000)][int]$SampleCount = 2000,
    [ValidateRange(0, 86400)][int]$DurationSeconds = 0,
    [ValidateRange(1, 100)][int]$Concurrency = 20,
    [ValidateRange(1, 300)][int]$TimeoutSeconds = 10,
    [string]$RunId,
    [switch]$SkipCertificateCheck
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$kitRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $kitRoot 'Common\TestHelpers.ps1')
if (-not $RunId) { $RunId = New-TestRunId }
$metadata = [ordered]@{ TestCaseId='TC-06'; TestName='Baseline and inline performance'; CoverageCategory='B'; CveReference=(Get-NotApplicableReference 'performance test') }
try {
    $baseUri = Resolve-SafeTargetUri -TargetUrl $TargetUrl
    $uri = Join-SafeTargetUri -BaseUri $baseUri -Path $Path
}
catch { throw "TC-06 target validation failed: $($_.Exception.Message)" }
$resultDirectory = New-ResultDirectory -RunId $RunId -TestCaseId $metadata.TestCaseId
if ($SkipCertificateCheck) { Write-Warning 'TLS certificate validation is being bypassed for this run only.' }
if ($WarmupCount -gt 0) {
    Write-Host "Running $WarmupCount warmup requests (not included in measured samples)."
    $null = @(Invoke-RequestBatch -TargetUri $uri -RunId $RunId -TestCaseId $metadata.TestCaseId -ProbeId 'WARMUP' -SampleCount $WarmupCount -Concurrency $Concurrency -TimeoutSeconds $TimeoutSeconds -Phase $Phase -SkipCertificateCheck:$SkipCertificateCheck)
}
$started = [datetime]::UtcNow
$samples = @(Invoke-RequestBatch -TargetUri $uri -RunId $RunId -TestCaseId $metadata.TestCaseId -ProbeId 'PERFORMANCE' -SampleCount $SampleCount -DurationSeconds $DurationSeconds -Concurrency $Concurrency -TimeoutSeconds $TimeoutSeconds -Phase $Phase -SkipCertificateCheck:$SkipCertificateCheck)
$ended = [datetime]::UtcNow
$stats = Get-RequestStatistics -Samples $samples
$target = Get-SanitizedTarget $uri
$record = New-ResultRecord -Values @{
    RunId=$RunId; CorrelationId=if ($samples.Count -gt 0) { $samples[0].CorrelationId } else { New-CorrelationId -RunId $RunId -TestCaseId $metadata.TestCaseId -ProbeId 'PERFORMANCE' }
    TestCaseId=$metadata.TestCaseId; TestName=$metadata.TestName; CoverageCategory=$metadata.CoverageCategory; ProbeId='PERFORMANCE'; ProbeName='Warmup plus measured HTTPS run'
    CveReference=$metadata.CveReference; Phase=$Phase; StartTimeUtc=Get-UtcTimestamp $started; EndTimeUtc=Get-UtcTimestamp $ended; DurationMs=[Math]::Round(($ended-$started).TotalMilliseconds,3)
    SkipCertificateCheck=[bool]$SkipCertificateCheck; ManualEvidenceRequired=$true; TargetUrl=$target.TargetUrl; TargetScheme=$target.TargetScheme; TargetHost=$target.TargetHost
    TargetPort=$target.TargetPort; TargetPath=$target.TargetPath; Method='GET'; RequestCount=$stats.RequestCount; SuccessCount=$stats.SuccessCount; FailureCount=$stats.FailureCount
    StatusDistribution=$stats.StatusDistribution; LatencyP50Ms=$stats.LatencyP50Ms; LatencyP95Ms=$stats.LatencyP95Ms; LatencyP99Ms=$stats.LatencyP99Ms
    ThroughputRequestsPerSecond=$stats.ThroughputRequestsPerSecond; ExpectedOutcome='Compare like-for-like Baseline and Inline runs; added latency <=20 ms normal and <=50 ms peak.'
    ObservedOutcome="$Phase p50=$($stats.LatencyP50Ms) ms, p95=$($stats.LatencyP95Ms) ms, p99=$($stats.LatencyP99Ms) ms, throughput=$($stats.ThroughputRequestsPerSecond) req/s, errors=$($stats.FailureCount)."
    Verdict='MANUAL_REQUIRED'; Notes='Route-only Baseline/Inline switching is manual. The previous lab baseline p99 was not captured; the old inline p99 outlier cannot be attributed to the firewall.'
}
$null = Write-TestArtifacts -ResultDirectory $resultDirectory -Records @($record) -Samples $samples -AdditionalSummary @(
    'Run the other phase with identical path, count/duration, concurrency, warmup, and application state.',
    'Archive ALB metrics/access logs and PAN-OS evidence with this run ID.'
)
Write-Output "RESULT_DIR=$resultDirectory"
