[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$TargetUrl,
    [string]$Path = '/',
    [ValidateRange(1, 100000)][int]$RequestCount = 20,
    [ValidateRange(1, 300)][int]$TimeoutSeconds = 10,
    [string]$RunId,
    [switch]$SkipCertificateCheck
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$kitRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $kitRoot 'Common\TestHelpers.ps1')
if (-not $RunId) { $RunId = New-TestRunId }
$baseUri = Resolve-SafeTargetUri -TargetUrl $TargetUrl
$uri = Join-SafeTargetUri -BaseUri $baseUri -Path $Path
$resultDirectory = New-ResultDirectory -RunId $RunId -TestCaseId 'TC-08'
if ($SkipCertificateCheck) { Write-Warning 'TLS certificate validation is being bypassed for this run only.' }
$started = [datetime]::UtcNow
$samples = @(Invoke-RequestBatch -TargetUri $uri -RunId $RunId -TestCaseId 'TC-08' -ProbeId 'ROUTE-GENEVE-EVIDENCE' -SampleCount $RequestCount -Concurrency 1 -TimeoutSeconds $TimeoutSeconds -SkipCertificateCheck:$SkipCertificateCheck)
$ended = [datetime]::UtcNow
$stats = Get-RequestStatistics -Samples $samples
$target = Get-SanitizedTarget $uri
$record = New-ResultRecord -Values @{
    RunId=$RunId; CorrelationId=if ($samples.Count -gt 0) { $samples[0].CorrelationId } else { New-CorrelationId -RunId $RunId -TestCaseId 'TC-08' -ProbeId 'ROUTE-GENEVE-EVIDENCE' }
    TestCaseId='TC-08'; TestName='GWLB transparent route-only insertion'; CoverageCategory='B'; ProbeId='ROUTE-GENEVE-EVIDENCE'; ProbeName='Timestamped normal HTTPS traffic'
    CveReference=(Get-NotApplicableReference 'architecture/control test'); StartTimeUtc=Get-UtcTimestamp $started; EndTimeUtc=Get-UtcTimestamp $ended; DurationMs=[Math]::Round(($ended-$started).TotalMilliseconds,3)
    SkipCertificateCheck=[bool]$SkipCertificateCheck; ManualEvidenceRequired=$true; TargetUrl=$target.TargetUrl; TargetScheme=$target.TargetScheme; TargetHost=$target.TargetHost
    TargetPort=$target.TargetPort; TargetPath=$target.TargetPath; Method='GET'; RequestCount=$stats.RequestCount; SuccessCount=$stats.SuccessCount; FailureCount=$stats.FailureCount
    StatusDistribution=$stats.StatusDistribution; LatencyP50Ms=$stats.LatencyP50Ms; LatencyP95Ms=$stats.LatencyP95Ms; LatencyP99Ms=$stats.LatencyP99Ms
    ThroughputRequestsPerSecond=$stats.ThroughputRequestsPerSecond; ExpectedOutcome='Normal traffic succeeds while route tables provide the only insertion change and PAN-OS GENEVE decapsulation/encapsulation counters increase.'
    ObservedOutcome="Client requests=$($stats.RequestCount), successes=$($stats.SuccessCount), failures=$($stats.FailureCount). GENEVE and route-only insertion are not client-verifiable."
    Verdict='MANUAL_REQUIRED'; Notes='Capture route tables and before/after flow_rcv_geneve_fast_decap and flow_tx_geneve_encap counters over the same UTC request window; confirm ALB and application configuration stayed unchanged.'
}
$null = Write-TestArtifacts -ResultDirectory $resultDirectory -Records @($record) -Samples $samples -AdditionalSummary @(
    'Manual evidence: AWS route tables target the approved GWLB endpoints in both directions.',
    'Manual evidence: PAN-OS GENEVE decap/encap counters increase over the same UTC request window.'
)
Write-Output "RESULT_DIR=$resultDirectory"
