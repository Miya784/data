[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$TargetUrl,
    [Parameter(Mandatory = $true)][ValidateSet('Baseline', 'Inline')][string]$Phase,
    [ValidateSet('LOG4SHELL', 'SHELLSHOCK', 'STRUTS-S2-045')][string]$ProbeId = 'LOG4SHELL',
    [string]$ComparisonId,
    [ValidateRange(1, 300)][int]$TimeoutSeconds = 10,
    [string]$RunId,
    [switch]$SkipCertificateCheck,
    [switch]$ConfirmAuthorizedTesting
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$kitRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $kitRoot 'Common\TestHelpers.ps1')
Assert-AuthorizedTesting -AuthorizationConfirmed ([bool]$ConfirmAuthorizedTesting) -TestCaseId 'TC-05'
Write-Warning 'AUTHORIZED SECURITY TEST: route or policy changes are manual. This script sends one inert detection payload and never changes infrastructure.'
if (-not $RunId) { $RunId = New-TestRunId }
if (-not $ComparisonId) { $ComparisonId = New-TestRunId }
$baseUri = Resolve-SafeTargetUri -TargetUrl $TargetUrl
$probe = @(Get-SafeSecurityProbeDefinitions -MarkerId $ComparisonId | Where-Object { $_.ProbeId -eq $ProbeId })[0]
if (-not $probe) { throw "Unknown TC-05 probe: $ProbeId" }
$payloadHash = Get-SecurityProbePayloadHash -Probe $probe
$uri = Join-SafeTargetUri -BaseUri $baseUri -Path $probe.Path
$resultDirectory = New-ResultDirectory -RunId $RunId -TestCaseId 'TC-05'
if ($SkipCertificateCheck) { Write-Warning 'TLS certificate validation is being bypassed for this run only.' }
$http = Invoke-SafeHttpRequest -TargetUri $uri -RunId $RunId -TestCaseId 'TC-05' -ProbeId $probe.ProbeId -Method $probe.Method -Headers $probe.Headers -Body $probe.Body -ContentType $probe.ContentType -TimeoutSeconds $TimeoutSeconds -SkipCertificateCheck:$SkipCertificateCheck
$target = Get-SanitizedTarget $uri
$record = New-ResultRecord -Values @{
    RunId=$RunId; CorrelationId=$http.CorrelationId; TestCaseId='TC-05'; TestName='Virtual patch baseline versus inline'; CoverageCategory='B'
    ProbeId=$probe.ProbeId; ProbeName=$probe.ProbeName; CveReference=$probe.CveReference; Phase=$Phase; AuthorizationConfirmed=$true
    SkipCertificateCheck=[bool]$SkipCertificateCheck; ManualEvidenceRequired=$true; StartTimeUtc=$http.TimestampUtc; EndTimeUtc=$http.EndTimeUtc; DurationMs=$http.LatencyMs
    TargetUrl=$target.TargetUrl; TargetScheme=$target.TargetScheme; TargetHost=$target.TargetHost; TargetPort=$target.TargetPort; TargetPath=$target.TargetPath
    Method=$probe.Method; StatusCode=$http.StatusCode; TransportOutcome=$http.TransportOutcome; RequestCount=1
    SuccessCount=if ($http.Success) { 1 } else { 0 }; FailureCount=if ($http.Success) { 0 } else { 1 }
    StatusDistribution=[ordered]@{ ([string]$(if ($null -eq $http.StatusCode) { 'NO_STATUS' } else { $http.StatusCode })) = 1 }
    LatencyP50Ms=$http.LatencyMs; LatencyP95Ms=$http.LatencyMs; LatencyP99Ms=$http.LatencyMs
    ExpectedOutcome='The identical approved probe reaches the test application during Baseline and is blocked during Inline, with PAN-OS evidence matched by UTC, tuple, rule/session, signature/action, and request order.'
    ObservedOutcome="$Phase client transport=$($http.TransportOutcome), status=$($http.StatusCode), comparisonId=$ComparisonId, payloadSha256=$payloadHash."
    Verdict='MANUAL_REQUIRED'; ExpectedPaloSignatureIds=$probe.ExpectedPaloSignatureIds; ErrorCategory=$http.ErrorCategory; ErrorMessage=$http.ErrorMessage
    Notes="ComparisonId=$ComparisonId; PayloadSha256=$payloadHash. Operator must record route state and restore the approved inline routes after Baseline. Custom headers are not assumed to be external log fields."
}
$sample = New-SampleRecord -Sequence 1 -HttpResult $http -TargetUri $uri -RunId $RunId -TestCaseId 'TC-05' -ProbeId $probe.ProbeId -Phase $Phase
$null = Write-TestArtifacts -ResultDirectory $resultDirectory -Records @($record) -Samples @($sample) -AdditionalSummary @(
    'AUTHORIZATION CONFIRMED: the operator explicitly enabled this security probe.',
    "ComparisonId=$ComparisonId",
    "PayloadSha256=$payloadHash",
    'AWS route changes and PAN-OS policy/log evidence are manual operator actions; this script performs neither.',
    'Match external PAN-OS evidence by UTC window, tuple, rule/session, signature/action, and request order.'
)
Write-Output "RESULT_DIR=$resultDirectory"
