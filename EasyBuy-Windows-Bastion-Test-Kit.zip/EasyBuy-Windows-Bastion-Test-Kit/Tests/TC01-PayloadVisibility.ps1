[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$TargetUrl,
    [string]$Path = '/',
    [ValidateRange(1, 300)][int]$TimeoutSeconds = 10,
    [string]$RunId,
    [switch]$SkipCertificateCheck
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$kitRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $kitRoot 'Common\TestHelpers.ps1')
if (-not $RunId) { $RunId = New-TestRunId }
$metadata = [ordered]@{
    TestCaseId = 'TC-01'
    TestName = 'ALB TLS termination and payload visibility'
    CoverageCategory = 'B'
    CveReference = Get-NotApplicableReference 'control/architecture test'
}

try {
    $baseUri = Resolve-SafeTargetUri -TargetUrl $TargetUrl
    $uri = Join-SafeTargetUri -BaseUri $baseUri -Path $Path
}
catch { throw "TC-01 target validation failed: $($_.Exception.Message)" }
$resultDirectory = New-ResultDirectory -RunId $RunId -TestCaseId $metadata.TestCaseId
if ($SkipCertificateCheck) { Write-Warning 'TLS certificate validation is being bypassed for this run only.' }
$started = [datetime]::UtcNow
$tls = Get-TlsProbe -TargetUri $uri -TimeoutSeconds $TimeoutSeconds -SkipCertificateCheck:$SkipCertificateCheck
$http = Invoke-SafeHttpRequest -TargetUri $uri -RunId $RunId -TestCaseId $metadata.TestCaseId -ProbeId 'PAYLOAD-VISIBILITY' -Headers @{ 'X-EasyBuy-Visibility-Marker' = $RunId } -TimeoutSeconds $TimeoutSeconds -SkipCertificateCheck:$SkipCertificateCheck
$ended = [datetime]::UtcNow
$target = Get-SanitizedTarget $uri
$verdict = if ($http.Success -and $tls.Success) { 'MANUAL_REQUIRED' } else { 'INCONCLUSIVE' }
$record = New-ResultRecord -Values @{
    RunId = $RunId; CorrelationId = $http.CorrelationId; TestCaseId = $metadata.TestCaseId; TestName = $metadata.TestName
    CoverageCategory = $metadata.CoverageCategory; ProbeId = 'PAYLOAD-VISIBILITY'; ProbeName = 'Timestamped HTTPS visibility request'
    CveReference = $metadata.CveReference; StartTimeUtc = Get-UtcTimestamp $started; EndTimeUtc = Get-UtcTimestamp $ended
    DurationMs = [Math]::Round(($ended - $started).TotalMilliseconds, 3); SkipCertificateCheck = [bool]$SkipCertificateCheck
    ManualEvidenceRequired = $true; TargetUrl = $target.TargetUrl; TargetScheme = $target.TargetScheme; TargetHost = $target.TargetHost
    TargetPort = $target.TargetPort; TargetPath = $target.TargetPath; Method = 'GET'; StatusCode = $http.StatusCode
    TransportOutcome = $http.TransportOutcome; TlsProtocol = $tls.TlsProtocol; CipherSuite = $tls.CipherSuite
    CertificateSubject = $tls.CertificateSubject; CertificateIssuer = $tls.CertificateIssuer
    CertificateThumbprint = $tls.CertificateThumbprint; CertificateSerialNumber = $tls.CertificateSerialNumber
    CertificateNotBeforeUtc = $tls.CertificateNotBeforeUtc; CertificateNotAfterUtc = $tls.CertificateNotAfterUtc
    CertificateValidationSucceeded = $tls.CertificateValidationSucceeded; RequestCount = 1
    SuccessCount = if ($http.Success) { 1 } else { 0 }; FailureCount = if ($http.Success) { 0 } else { 1 }
    StatusDistribution = [ordered]@{ ([string]$(if ($null -eq $http.StatusCode) { 'NO_STATUS' } else { $http.StatusCode })) = 1 }
    LatencyP50Ms = $http.LatencyMs; LatencyP95Ms = $http.LatencyMs; LatencyP99Ms = $http.LatencyMs
    ExpectedOutcome = 'A valid client-to-ALB TLS connection plus manual evidence that the ALB-to-backend HTTP flow and an approved payload probe were visible to PAN-OS.'
    ObservedOutcome = "Client transport=$($http.TransportOutcome), status=$($http.StatusCode), TLS=$($tls.TlsProtocol). PAN-OS visibility is not proven by the client."
    Verdict = $verdict; ExpectedPaloSignatureIds = @(); ErrorCategory = if ($http.ErrorCategory) { $http.ErrorCategory } else { $tls.ErrorCategory }
    ErrorMessage = if ($http.ErrorMessage) { $http.ErrorMessage } else { $tls.ErrorMessage }
    Notes = 'TLS ends at the ALB. Match allow-alb-to-app by UTC window, source/destination tuple, rule, and approved probe evidence. Ordinary PAN-OS logs need not retain the correlation header.'
}
$sample = New-SampleRecord -Sequence 1 -HttpResult $http -TlsResult $tls -TargetUri $uri -RunId $RunId -TestCaseId $metadata.TestCaseId -ProbeId 'PAYLOAD-VISIBILITY'
$null = Write-TestArtifacts -ResultDirectory $resultDirectory -Records @($record) -Samples @($sample) -AdditionalSummary @(
    'Required PAN-OS evidence: match allow-alb-to-app flow and approved payload evidence using UTC, tuple, rule, and probe/signature fields.',
    'The X-EasyBuy headers are exact local/wire markers; use them externally only if an approved logging carrier was configured and validated.',
    'A client-side success or Traffic row alone does not prove firewall payload inspection.'
)
Write-Output "RESULT_DIR=$resultDirectory"
