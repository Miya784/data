[CmdletBinding()]
param(
    [string]$TargetUrl,
    [string]$Path = '/',
    [ValidateRange(1, 86400)][int]$DurationSeconds = 100,
    [ValidateRange(100, 60000)][int]$CadenceMilliseconds = 300,
    [ValidateRange(1, 300)][int]$TimeoutSeconds = 2,
    [ValidateRange(1, 100)][int]$MaxConcurrency = 8,
    [string]$RunId,
    [switch]$SkipCertificateCheck,
    [ValidateLength(1, 80)][string]$WriteEventMarker,
    [string]$MarkerFile
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$kitRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $kitRoot 'Common\TestHelpers.ps1')
if ($WriteEventMarker) {
    if (-not $MarkerFile) { throw '-MarkerFile is required with -WriteEventMarker.' }
    Write-Output (Write-EventMarker -MarkerFile $MarkerFile -Label $WriteEventMarker)
    return
}
if (-not $TargetUrl) { throw '-TargetUrl is required when running the monitor.' }
if (-not $RunId) { $RunId = New-TestRunId }
$baseUri = Resolve-SafeTargetUri -TargetUrl $TargetUrl
$uri = Join-SafeTargetUri -BaseUri $baseUri -Path $Path
$resultDirectory = New-ResultDirectory -RunId $RunId -TestCaseId 'TC-07'
$markerPath = Join-Path $resultDirectory 'operator-markers.txt'
if ($SkipCertificateCheck) { Write-Warning 'TLS certificate validation is being bypassed for this run only.' }
Write-Warning 'MONITOR ONLY: this script does not stop instances, alter NACLs, change routes, or inject failure.'
Write-Host 'This measures new HTTPS connection recovery (interpretation A), not PAN-OS Session Resiliency.'
Write-Host "Press M or Enter for immediate key markers, or use -WriteEventMarker with: $markerPath"
$started = [datetime]::UtcNow
$monitor = Invoke-RequestMonitor -TargetUri $uri -RunId $RunId -TestCaseId 'TC-07' -ProbeId 'NEW-CONNECTION' -DurationSeconds $DurationSeconds -CadenceMilliseconds $CadenceMilliseconds -TimeoutSeconds $TimeoutSeconds -MarkerFile $markerPath -MaxConcurrency $MaxConcurrency -SkipCertificateCheck:$SkipCertificateCheck
$ended = [datetime]::UtcNow
$samples = @($monitor.Samples)
$stats = Get-RequestStatistics -Samples $samples
$outage = Get-OutageStatistics -Samples $samples
$target = Get-SanitizedTarget $uri
$markerText = @($monitor.Markers | ForEach-Object { $_.TimestampUtc + '=' + $_.Label }) -join '; '
$verdict = if ($outage.WorstOutageDurationMs -gt 5000) { 'FAIL' } else { 'MANUAL_REQUIRED' }
$record = New-ResultRecord -Values @{
    RunId=$RunId; CorrelationId=if ($samples.Count -gt 0) { $samples[0].CorrelationId } else { New-CorrelationId -RunId $RunId -TestCaseId 'TC-07' -ProbeId 'NEW-CONNECTION' }
    TestCaseId='TC-07'; TestName='HA new-connection failover monitor'; CoverageCategory='B'; ProbeId='NEW-CONNECTION'; ProbeName='Continuous HTTPS new-connection monitor'
    CveReference=(Get-NotApplicableReference 'availability/architecture test'); StartTimeUtc=Get-UtcTimestamp $started; EndTimeUtc=Get-UtcTimestamp $ended; DurationMs=[Math]::Round(($ended-$started).TotalMilliseconds,3)
    SkipCertificateCheck=[bool]$SkipCertificateCheck; OperatorMarker=$markerText; ManualEvidenceRequired=$true; TargetUrl=$target.TargetUrl; TargetScheme=$target.TargetScheme
    TargetHost=$target.TargetHost; TargetPort=$target.TargetPort; TargetPath=$target.TargetPath; Method='GET'; RequestCount=$stats.RequestCount; SuccessCount=$stats.SuccessCount
    FailureCount=$stats.FailureCount; StatusDistribution=$stats.StatusDistribution; LatencyP50Ms=$stats.LatencyP50Ms; LatencyP95Ms=$stats.LatencyP95Ms; LatencyP99Ms=$stats.LatencyP99Ms
    ThroughputRequestsPerSecond=$stats.ThroughputRequestsPerSecond; WorstConsecutiveFailures=$outage.WorstConsecutiveFailures; WorstOutageStartUtc=$outage.WorstOutageStartUtc
    WorstOutageEndUtc=$outage.WorstOutageEndUtc; WorstOutageDurationMs=$outage.WorstOutageDurationMs; MaxInterSampleGapMs=$outage.MaxInterSampleGapMs
    ExpectedOutcome='Automatic recovery of new connections with no more than 5 seconds of measured outage.'
    ObservedOutcome="Samples=$($stats.RequestCount), failures=$($stats.FailureCount), worstConsecutiveFailures=$($outage.WorstConsecutiveFailures), worstOutageMs=$($outage.WorstOutageDurationMs), maxInterSampleGapMs=$($outage.MaxInterSampleGapMs)."
    Verdict=$verdict; Notes='Interpretation A only. Lab hard failure measured about 7 s interruption and 10-13 s GWLB detection; full-AZ end-to-end recovery was about 50 s, so the lab result remains FAIL against the strict <=5 s criterion.'
}
$null = Write-TestArtifacts -ResultDirectory $resultDirectory -Records @($record) -Samples $samples -AdditionalSummary @(
    "Marker file: $markerPath",
    'An authorized operator must perform stop/force-stop/NACL/AZ actions separately in AWS Console and preserve exact marker timestamps.',
    'A run at or below 5 seconds still needs GWLB/ALB/AWS evidence before approval; a measured outage above 5 seconds is FAIL.'
)
Write-Output "RESULT_DIR=$resultDirectory"
