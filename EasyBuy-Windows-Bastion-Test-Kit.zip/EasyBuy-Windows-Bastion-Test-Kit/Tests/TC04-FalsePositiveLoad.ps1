[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$TargetUrl,
    [string]$Path = '/',
    [ValidateRange(1, 1000000)][int]$SampleCount = 10000,
    [ValidateRange(0, 86400)][int]$DurationSeconds = 0,
    [ValidateRange(1, 100)][int]$Concurrency = 10,
    [ValidateRange(1, 300)][int]$TimeoutSeconds = 10,
    [string]$RunId,
    [switch]$SkipCertificateCheck
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$kitRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $kitRoot 'Common\TestHelpers.ps1')
if (-not $RunId) { $RunId = New-TestRunId }
$metadata = [ordered]@{ TestCaseId='TC-04'; TestName='False-positive normal load'; CoverageCategory='B'; CveReference=(Get-NotApplicableReference 'control/performance test') }
try {
    $baseUri = Resolve-SafeTargetUri -TargetUrl $TargetUrl
    $uri = Join-SafeTargetUri -BaseUri $baseUri -Path $Path
}
catch { throw "TC-04 target validation failed: $($_.Exception.Message)" }
$resultDirectory = New-ResultDirectory -RunId $RunId -TestCaseId $metadata.TestCaseId
if ($SkipCertificateCheck) { Write-Warning 'TLS certificate validation is being bypassed for this run only.' }
$started = [datetime]::UtcNow
$samples = @(Invoke-RequestBatch -TargetUri $uri -RunId $RunId -TestCaseId $metadata.TestCaseId -ProbeId 'NORMAL-LOAD' -SampleCount $SampleCount -DurationSeconds $DurationSeconds -Concurrency $Concurrency -TimeoutSeconds $TimeoutSeconds -SkipCertificateCheck:$SkipCertificateCheck)
$ended = [datetime]::UtcNow
$stats = Get-RequestStatistics -Samples $samples
$target = Get-SanitizedTarget $uri
$record = New-ResultRecord -Values @{
    RunId=$RunId; CorrelationId=if ($samples.Count -gt 0) { $samples[0].CorrelationId } else { New-CorrelationId -RunId $RunId -TestCaseId $metadata.TestCaseId -ProbeId 'NORMAL-LOAD' }
    TestCaseId=$metadata.TestCaseId; TestName=$metadata.TestName; CoverageCategory=$metadata.CoverageCategory; ProbeId='NORMAL-LOAD'; ProbeName='Representative normal HTTPS traffic'
    CveReference=$metadata.CveReference; StartTimeUtc=Get-UtcTimestamp $started; EndTimeUtc=Get-UtcTimestamp $ended; DurationMs=[Math]::Round(($ended-$started).TotalMilliseconds,3)
    SkipCertificateCheck=[bool]$SkipCertificateCheck; ManualEvidenceRequired=$true; TargetUrl=$target.TargetUrl; TargetScheme=$target.TargetScheme; TargetHost=$target.TargetHost
    TargetPort=$target.TargetPort; TargetPath=$target.TargetPath; Method='GET'; RequestCount=$stats.RequestCount; SuccessCount=$stats.SuccessCount; FailureCount=$stats.FailureCount
    StatusDistribution=$stats.StatusDistribution; LatencyP50Ms=$stats.LatencyP50Ms; LatencyP95Ms=$stats.LatencyP95Ms; LatencyP99Ms=$stats.LatencyP99Ms
    ThroughputRequestsPerSecond=$stats.ThroughputRequestsPerSecond; ExpectedOutcome='False-positive rate below 0.1%, confirmed by matching PAN-OS logs, during representative business traffic.'
    ObservedOutcome="Client successes=$($stats.SuccessCount), failures=$($stats.FailureCount), throughput=$($stats.ThroughputRequestsPerSecond) req/s."
    Verdict='MANUAL_REQUIRED'; ErrorCategory=$null; ErrorMessage=$null
    Notes='HTTP success alone cannot prove zero false positives. Review Threat and Traffic logs, including historical lab signature 35075, and classify only approved business transactions.'
}
$null = Write-TestArtifacts -ResultDirectory $resultDirectory -Records @($record) -Samples $samples -AdditionalSummary @(
    'Required PAN-OS evidence: matching allow-alb-to-app Traffic and Threat logs.',
    'Specifically check whether Apache Benchmark-like DoS signature 35075 fired and what action applied.'
)
Write-Output "RESULT_DIR=$resultDirectory"
