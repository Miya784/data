[CmdletBinding()]
param(
    [string]$ConfigPath,
    [string[]]$Tests = @('TC01', 'TC02'),
    [switch]$List,
    [switch]$ConfirmAuthorizedTesting,
    [ValidateSet('Baseline', 'Inline')][string]$Phase,
    [string]$ComparisonId,
    [switch]$SkipCertificateCheck,
    [switch]$ConfirmDirectEgressPath,
    [switch]$AllowDirectHttpBaseline
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$kitRoot = $PSScriptRoot
# Resolve the default config path here, not in the param block: under [CmdletBinding()]
# on Windows PowerShell 5.1, $PSScriptRoot is empty while parameter defaults are bound,
# so a param-level default would produce a bad path. $kitRoot is populated by now.
if ([string]::IsNullOrWhiteSpace($ConfigPath)) { $ConfigPath = Join-Path $kitRoot 'Test-Config.psd1' }
. (Join-Path $kitRoot 'Common\TestHelpers.ps1')
$catalog = @(
    [pscustomobject]@{ Id='TC01'; File='TC01-PayloadVisibility.ps1'; Safety='Harmless default preflight'; Manual=$true },
    [pscustomobject]@{ Id='TC02'; File='TC02-Tls13.ps1'; Safety='Harmless default preflight'; Manual=$false },
    [pscustomobject]@{ Id='TC03'; File='TC03-ThreatPrevention.ps1'; Safety='Authorized security payloads'; Manual=$true },
    [pscustomobject]@{ Id='TC04'; File='TC04-FalsePositiveLoad.ps1'; Safety='Explicit load test'; Manual=$true },
    [pscustomobject]@{ Id='TC05'; File='TC05-VirtualPatch.ps1'; Safety='Authorized payload; manual route phase'; Manual=$true },
    [pscustomobject]@{ Id='TC06'; File='TC06-Performance.ps1'; Safety='Explicit load test; manual route phase'; Manual=$true },
    [pscustomobject]@{ Id='TC07'; File='TC07-HAFailoverMonitor.ps1'; Safety='Monitor only; operator injects failure'; Manual=$true },
    [pscustomobject]@{ Id='TC08'; File='TC08-GWLBTransparentInsertion.ps1'; Safety='Harmless traffic; manual counters'; Manual=$true },
    [pscustomobject]@{ Id='TC09'; File='TC09-SIEMLogging.ps1'; Safety='Harmless events; manual SIEM check'; Manual=$true },
    [pscustomobject]@{ Id='TC10'; File='TC10-CertificateRotation.ps1'; Safety='Monitor only; operator rotates ACM'; Manual=$true },
    [pscustomobject]@{ Id='TC11'; File=$null; Safety='Manual compliance/document review only'; Manual=$true },
    [pscustomobject]@{ Id='TC12'; File='TC12-StatefulAccessControl.ps1'; Safety='Explicit customer matrix only'; Manual=$true },
    [pscustomobject]@{ Id='TC13'; File='TC13-AntiMalware.ps1'; Safety='Authorized EICAR payload'; Manual=$true }
)
if ($List) {
    $catalog | Format-Table Id, Safety, Manual -AutoSize
    return
}

$selected = @($Tests | ForEach-Object { $_.ToUpperInvariant().Replace('-', '') } | Select-Object -Unique)
$unknown = @($selected | Where-Object { $id = $_; -not @($catalog | Where-Object { $_.Id -eq $id }).Count })
if ($unknown.Count -gt 0) { throw 'Unknown test selection(s): ' + ($unknown -join ', ') }
$guarded = @($selected | Where-Object { @('TC03', 'TC05', 'TC13') -contains $_ })
if ($guarded.Count -gt 0 -and -not $ConfirmAuthorizedTesting) {
    throw ('Tests {0} contain security-test payloads and require -ConfirmAuthorizedTesting. No selected test was started.' -f ($guarded -join ', '))
}
if (($selected -contains 'TC05' -or $selected -contains 'TC06') -and -not $Phase) {
    throw '-Phase Baseline|Inline is required when TC05 or TC06 is selected. No selected test was started.'
}
if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) { throw "Config file not found: $ConfigPath" }
$config = Import-PowerShellDataFile -LiteralPath $ConfigPath
if (-not $config.ContainsKey('TargetUrl')) { throw 'Config requires TargetUrl.' }
$null = Resolve-SafeTargetUri -TargetUrl ([string]$config.TargetUrl) -AllowHttp:([bool]$AllowDirectHttpBaseline)
if ($SkipCertificateCheck) { Write-Warning 'TLS certificate validation will be bypassed per request for this suite only.' }
if ($guarded.Count -gt 0) { Write-Warning 'AUTHORIZED SECURITY TESTING was explicitly confirmed for the selected guarded tests.' }

$runId = New-TestRunId
$suiteDirectory = New-ResultDirectory -RunId $runId -TestCaseId 'SUITE'
$records = New-Object Collections.ArrayList
$launchFailures = New-Object Collections.ArrayList
foreach ($testId in $selected) {
    $entry = @($catalog | Where-Object { $_.Id -eq $testId })[0]
    if ($testId -eq 'TC11') {
        $record = New-ResultRecord -Values @{
            RunId=$runId; CorrelationId=New-CorrelationId -RunId $runId -TestCaseId 'TC-11' -ProbeId 'MANUAL-CHECKLIST'; TestCaseId='TC-11'
            TestName='Compliance/documentation review'; CoverageCategory='C'; ProbeId='MANUAL-CHECKLIST'; ProbeName='Manual checklist only'
            CveReference=(Get-NotApplicableReference 'compliance/documentation review'); StartTimeUtc=Get-UtcTimestamp; EndTimeUtc=Get-UtcTimestamp
            ManualEvidenceRequired=$true; ExpectedOutcome='Complete Manual/TC11-Compliance-Checklist.md without inventing an infrastructure objective.'
            ObservedOutcome='No Bastion traffic script exists for TC-11.'; Verdict='NOT_RUN'; Notes='Open the manual checklist and record owner, artifact, version/date, reviewer, decision, and gaps.'
        }
        $null = $records.Add($record)
        continue
    }

    $scriptPath = Join-Path (Join-Path $kitRoot 'Tests') $entry.File
    $common = @{ TargetUrl=[string]$config.TargetUrl; RunId=$runId; SkipCertificateCheck=[bool]$SkipCertificateCheck }
    if ($config.ContainsKey('RequestTimeoutSeconds')) { $common.TimeoutSeconds = [int]$config.RequestTimeoutSeconds }
    switch ($testId) {
        'TC01' { $common.Path=[string]$config.HealthPath }
        'TC02' { $common.Path=[string]$config.HealthPath; $common.Attempts=[int]$config.TlsAttempts }
        'TC03' { $common.ConfirmAuthorizedTesting=[bool]$ConfirmAuthorizedTesting }
        'TC04' { $common.Path=[string]$config.NormalPath; $common.SampleCount=[int]$config.NormalSampleCount; $common.Concurrency=[int]$config.NormalConcurrency }
        'TC05' { $common.Phase=$Phase; $common.ConfirmAuthorizedTesting=[bool]$ConfirmAuthorizedTesting; if ($ComparisonId) { $common.ComparisonId=$ComparisonId } }
        'TC06' { $common.Path=[string]$config.NormalPath; $common.Phase=$Phase; $common.WarmupCount=[int]$config.PerformanceWarmupCount; $common.SampleCount=[int]$config.PerformanceSampleCount; $common.Concurrency=[int]$config.PerformanceConcurrency }
        'TC07' { $common.Path=[string]$config.HealthPath; $common.DurationSeconds=[int]$config.MonitorDurationSeconds; $common.CadenceMilliseconds=[int]$config.MonitorCadenceMilliseconds; $common.TimeoutSeconds=2 }
        'TC08' { $common.Path=[string]$config.NormalPath; $common.RequestCount=[int]$config.TransparentRequestCount }
        'TC09' { $common.Path=[string]$config.NormalPath; $common.EventCount=[int]$config.SiemEventCount }
        'TC10' { $common.Path=[string]$config.HealthPath; $common.DurationSeconds=[int]$config.MonitorDurationSeconds }
        'TC12' { $common.Rows=[object[]]$config.TC12Rows }
        'TC13' {
            $common.Path=[string]$config.UploadPath; $common.TrafficContext=[string]$config.AntiMalwareTrafficContext
            $common.ConfirmAuthorizedTesting=[bool]$ConfirmAuthorizedTesting; $common.ConfirmDirectEgressPath=[bool]$ConfirmDirectEgressPath
            $common.AllowDirectHttpBaseline=[bool]$AllowDirectHttpBaseline
        }
    }

    $start = [datetime]::UtcNow
    try {
        Write-Host "Starting $testId ..."
        $output = @(& $scriptPath @common)
        $resultLine = @($output | ForEach-Object { [string]$_ } | Where-Object { $_ -match '^RESULT_DIR=' } | Select-Object -Last 1)
        if ($resultLine.Count -eq 0) { throw "$testId did not report a result directory." }
        $childDirectory = $resultLine[0].Substring('RESULT_DIR='.Length)
        $childJson = Join-Path $childDirectory 'results.json'
        if (-not (Test-Path -LiteralPath $childJson -PathType Leaf)) { throw "$testId result JSON is missing." }
        $childRecords = @(Get-Content -LiteralPath $childJson -Raw | ConvertFrom-Json)
        $childVerdicts = @($childRecords | ForEach-Object { $_.Verdict })
        $suiteVerdict = if ($childVerdicts -contains 'FAIL') { 'FAIL' } elseif ($childVerdicts -contains 'INCONCLUSIVE') { 'INCONCLUSIVE' } elseif ($childVerdicts -contains 'MANUAL_REQUIRED') { 'MANUAL_REQUIRED' } else { 'PASS' }
        $end = [datetime]::UtcNow
        $record = New-ResultRecord -Values @{
            RunId=$runId; CorrelationId=New-CorrelationId -RunId $runId -TestCaseId ($testId.Insert(2, '-')) -ProbeId 'ORCHESTRATOR'
            TestCaseId=$testId.Insert(2, '-'); TestName='Suite launch status'; CoverageCategory=if ($entry.Manual) { 'B' } else { 'A' }; ProbeId='ORCHESTRATOR'; ProbeName='Selected-test launcher'
            CveReference=(Get-NotApplicableReference 'orchestrator status record; see per-probe result'); StartTimeUtc=Get-UtcTimestamp $start; EndTimeUtc=Get-UtcTimestamp $end
            DurationMs=[Math]::Round(($end-$start).TotalMilliseconds,3); AuthorizationConfirmed=($guarded -contains $testId); SkipCertificateCheck=[bool]$SkipCertificateCheck
            ManualEvidenceRequired=[bool]$entry.Manual; ExpectedOutcome='The selected test runs with its own safety gates and writes standalone result artifacts.'
            ObservedOutcome="Completed with child verdict(s): $($childVerdicts -join ','). ResultDirectory=$childDirectory"; Verdict=$suiteVerdict
            Notes="ChildResultDirectory=$childDirectory"
        }
        $null = $records.Add($record)
    }
    catch {
        $end = [datetime]::UtcNow
        # Keep ${testId} delimited. An undelimited reference immediately followed by a
        # colon parses as a scope/drive qualifier, which is a parse error in both
        # Windows PowerShell 5.1 and PowerShell 7.
        $null = $launchFailures.Add("${testId}: $($_.Exception.Message)")
        $record = New-ResultRecord -Values @{
            RunId=$runId; CorrelationId=New-CorrelationId -RunId $runId -TestCaseId ($testId.Insert(2, '-')) -ProbeId 'ORCHESTRATOR-ERROR'
            TestCaseId=$testId.Insert(2, '-'); TestName='Suite launch status'; CoverageCategory=if ($entry.Manual) { 'B' } else { 'A' }; ProbeId='ORCHESTRATOR-ERROR'; ProbeName='Selected-test launcher'
            CveReference=(Get-NotApplicableReference 'orchestrator status record; test did not complete'); StartTimeUtc=Get-UtcTimestamp $start; EndTimeUtc=Get-UtcTimestamp $end
            DurationMs=[Math]::Round(($end-$start).TotalMilliseconds,3); AuthorizationConfirmed=($guarded -contains $testId); SkipCertificateCheck=[bool]$SkipCertificateCheck
            ManualEvidenceRequired=$true; ExpectedOutcome='The selected test starts and writes result artifacts.'; ObservedOutcome=$_.Exception.Message
            Verdict='INCONCLUSIVE'; ErrorCategory=$_.Exception.GetType().FullName; ErrorMessage=$_.Exception.Message
        }
        $null = $records.Add($record)
        Write-Warning "$testId failed to complete; continuing with the remaining selected tests. $($_.Exception.Message)"
    }
}
$null = Write-TestArtifacts -ResultDirectory $suiteDirectory -Records @($records) -Samples @($records) -AdditionalSummary @(
    'The suite launcher never injects failure or changes AWS/PAN-OS configuration.',
    'Per-test directories contain the canonical traffic samples and evidence requirements.'
)
Write-Output "RESULT_DIR=$suiteDirectory"
if ($launchFailures.Count -gt 0) { throw ('One or more selected tests did not complete: ' + ($launchFailures -join '; ')) }
