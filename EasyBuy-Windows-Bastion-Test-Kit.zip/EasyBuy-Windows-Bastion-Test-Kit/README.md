# EasyBuy Windows Bastion Test Kit

Standalone, Windows PowerShell 5.1-first traffic generation and evidence collection for the EasyBuy Palo Alto VM-Series + AWS GWLB POC. PowerShell 7 is supported where practical. No third-party module, Python, OpenSSL, jq, AWS CLI, package installation, or administrator rights are required.

## Five-minute quick start

1. Copy the ZIP to the Windows Server Bastion, extract it, and open **Windows PowerShell** in the extracted `EasyBuy-Windows-Bastion-Test-Kit` directory.
2. Review the scripts and confirm the target, source CIDR, test window, operator, and authorization. The ALB security group must allow the Bastion source.
3. Copy the example and replace every placeholder; do not add credentials, cookies, tokens, or keys:
   ```powershell
   Copy-Item .\Test-Config.example.psd1 .\Test-Config.psd1
   notepad .\Test-Config.psd1
   ```
4. After review, remove downloaded-file blocking without weakening machine policy, then validate:
   ```powershell
   Get-ChildItem -Recurse -File | Unblock-File
   powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\Validate-Kit.ps1
   ```
   `-ExecutionPolicy Bypass` above applies only to that process. Do not set machine-wide `Unrestricted`.
5. Run harmless connectivity/TLS preflight, then inspect the printed timestamped directory beneath `results\`:
   ```powershell
   powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\Run-SelectedTests.ps1 -ConfigPath .\Test-Config.psd1
   ```

Use placeholders in commands, never production secrets. Direct examples:

```powershell
.\Tests\TC01-PayloadVisibility.ps1 -TargetUrl 'https://<approved-alb-fqdn>/' -Path '<health-path>'
.\Tests\TC02-Tls13.ps1 -TargetUrl 'https://<approved-alb-fqdn>/' -Path '<health-path>' -Attempts 20
.\Run-SelectedTests.ps1 -List
```

## Before the test window

Fill and approve:

- [ ] Target FQDN/base URL and final health/normal/upload paths
- [ ] Expected certificate DNS name
- [ ] Bastion/test source CIDR allowed by the ALB security group
- [ ] Admin-approved test window and `-ConfirmAuthorizedTesting` owner
- [ ] PAN-OS Traffic/Threat log viewer access
- [ ] SIEM receiver/operator and clock synchronization
- [ ] Baseline/inline route operator and rollback contact
- [ ] Failover action/rollback operator contact
- [ ] ACM rotation operator and rollback certificate

A same-VPC Bastion may resolve or reach the public ALB differently depending on DNS, route, and NAT behavior. Run TC-01/02 first and record the actual source/target context. Scripts never discover targets and remain on the user-supplied scheme/host/port.

## Architecture boundary and authorization

Client traffic uses **HTTPS 443 to the ALB**. TLS and the ACM certificate terminate at the ALB; the ALB forwards **HTTP 80 to the backend**. By customer decision, the firewall performs no decryption. It can inspect cleartext inbound application payloads after ALB termination, but it cannot inspect encrypted direct-egress HTTPS bodies. This distinction is critical for TC-01/02/10/13.

TC-03, TC-05, and TC-13 contain detection/security payloads. They refuse before traffic unless explicitly selected and given `-ConfirmAuthorizedTesting`; authorized runs print and record a warning. The TC-03 security probes carry representative signature-triggering vectors (for example the reflected-XSS, SQL-injection, SQLMap User-Agent, and Struts S2-045 multipart forms the firewall actually detects) so they exercise the matching PAN-OS signatures, yet remain safe as traffic: the kit performs no scanning, discovery, brute force, credential attack, persistence, reverse shell, extraction, live callback, destructive command, AWS change, PAN-OS change, or failure injection. Log4Shell/SSRF/XXE destinations use `.invalid`; the Shellshock and Struts probes are non-destructive (no runtime/process call, command, file read, IMDS target, or callback); EICAR is built in memory.

TLS validation is on by default. `-SkipCertificateCheck` is opt-in, visibly recorded, request/process-local, and prevents a clean certificate PASS. It never leaves a global validation callback disabled. The optional fallback invokes only `curl.exe`, after checking TLS 1.3 options; bare `curl` is never used. A local OS/.NET/curl limitation is `INCONCLUSIVE`, not a target failure.

## Test matrix

| TC | Requirement | Script/manual | Disruptive? | Authorization switch? | CVE | Evidence produced | External/manual evidence and pass criterion |
|---|---|---|---|---|---|---|---|
| TC-01 | Mandatory, B | `Tests/TC01-PayloadVisibility.ps1` | No | No | N/A — control/architecture test | TLS/cert, HTTP, local run/correlation IDs | `allow-alb-to-app` flow plus approved payload evidence matched by UTC/tuple/probe; client alone cannot prove inspection. |
| TC-02 | Mandatory, A | `Tests/TC02-Tls13.ps1` | No | No | N/A — protocol capability test | Forced TLS 1.3 attempts/cert evidence | All attempts TLS 1.3 with valid cert; local limitations are inconclusive. |
| TC-03 | Mandatory, B | `Tests/TC03-ThreatPrevention.ps1` | Security payloads | **Yes** | Three exact CVEs; generic probes N/A | Per-probe local ID/CVE/client symptom | Threat+Traffic rows matched by UTC/tuple/signature prove action/rule and approved ≥90% result. |
| TC-04 | Optional, B | `Tests/TC04-FalsePositiveLoad.ps1` | Load | No | N/A — control/performance test | Raw samples, counts, distribution, p50/p95/p99 | PAN-OS review proves false-positive rate <0.1%; inspect 35075 if seen. |
| TC-05 | Mandatory, B | `Tests/TC05-VirtualPatch.ps1` | Security payload + manual route change | **Yes** | Selected exact CVE | Phase/comparison/payload hash | Same probe reaches baseline and is logged/blocked inline; routes changed/restored manually. |
| TC-06 | Optional, B | `Tests/TC06-Performance.ps1` | Load + manual route change | No | N/A — performance test | Warmup-separated raw samples and p50/p95/p99 | Like-for-like Baseline/Inline comparison; ≤20 ms normal, ≤50 ms peak added latency. |
| TC-07 | Mandatory, B | `Tests/TC07-HAFailoverMonitor.ps1` | **Monitor only**; operator action separate | No | N/A — availability/architecture test | ~0.3 s samples, markers, outage/gap metrics | New connections recover automatically in ≤5 s plus AWS/GWLB/ALB evidence. Above 5 s is FAIL. |
| TC-08 | Mandatory, B | `Tests/TC08-GWLBTransparentInsertion.ps1` | No | No | N/A — architecture/control test | Timestamped normal request samples | Routes-only insertion, increasing GENEVE counters, unchanged ALB/app, 100% expected traffic. |
| TC-09 | Optional/on-site, B | `Tests/TC09-SIEMLogging.ps1` | No | No | N/A — logging/control test | Event UTC/local correlation IDs | SIEM rows matched to PAN fields prove complete arrival in <30 s. |
| TC-10 | Optional/on-site, B | `Tests/TC10-CertificateRotation.ps1` | **Monitor only**; ACM action separate | No | N/A — certificate lifecycle/control test | Before/during/after cert identity and continuity | ACM/listener evidence plus no request impact/cert warning. |
| TC-11 | On-site, C | `Manual/TC11-Compliance-Checklist.md` | No | No | N/A — compliance/documentation review | Manual checklist | Customer reviewer decides; no infrastructure objective or PASS is invented. |
| TC-12 | On-site, B | `Tests/TC12-StatefulAccessControl.ps1` | Customer matrix only | No | N/A — access-control test | One result per enabled row | PAN-OS rule/action matches every approved allow/deny row. |
| TC-13 | Optional/on-site, B | `Tests/TC13-AntiMalware.ps1` | EICAR payload | **Yes** | N/A — standardized anti-malware control test | In-memory EICAR symptom/local ID | Plain HTTP or ALB-terminated cleartext path logs/reset; direct HTTPS may pass without egress decryption. |

Coverage A means Bastion-runnable; B means generator/monitor plus manual evidence; C means manual-only. A client reset, timeout, 502, or success never substitutes for PAN-OS/AWS/SIEM proof.

## Commands and per-test sequence

Load configuration for convenient direct runs:

```powershell
$cfg = Import-PowerShellDataFile .\Test-Config.psd1
```

- **TC-01/02 preflight:** run the quick-start command. Expected symptom is a valid HTTPS response and certificate. TC-01 stays `MANUAL_REQUIRED` until `allow-alb-to-app` flow evidence and approved payload evidence are matched by UTC window, source/destination tuple, rule, and probe/signature. Traffic logs alone do not prove payload inspection; an authorized TC-03 signature or an approved capture can. TC-02 passes only with successful forced TLS 1.3 and normal certificate validation.
- **TC-03:** confirm the dedicated target/window/profile. Prerequisite: the Vulnerability Protection profile on `allow-alb-to-app` must reset critical/high/medium findings and carry threat exceptions that set signatures 36248 and 58005 to `reset-both`. Under the predefined `strict` profile those two low-severity SQL-injection signatures default to `alert`, so `SQLI-UNION` is detected but not blocked and the run cannot reach ≥90%. Then run:
  ```powershell
  .\Tests\TC03-ThreatPrevention.ps1 -TargetUrl $cfg.TargetUrl -ConfirmAuthorizedTesting
  ```
  Cross-check Threat and Traffic logs on `allow-alb-to-app`; match each probe using its UTC time, source/destination tuple, expected signature, and request order, then record signature/action and calculate the approved ≥90% set. CVE details are in `CVE-REFERENCE.md`.
- **TC-04:** use representative approved paths, not just synthetic benchmark traffic:
  ```powershell
  .\Tests\TC04-FalsePositiveLoad.ps1 -TargetUrl $cfg.TargetUrl -Path $cfg.NormalPath -SampleCount 10000 -Concurrency 10
  ```
  Review status distribution, errors, p50/p95/p99, then Threat logs (especially 35075 if present).
- **TC-05:** the route operator captures/restores routes; the script only repeats an identical safe probe:
  ```powershell
  $comparison = [guid]::NewGuid().ToString('N')
  .\Tests\TC05-VirtualPatch.ps1 -TargetUrl $cfg.TargetUrl -Phase Baseline -ComparisonId $comparison -ConfirmAuthorizedTesting
  .\Tests\TC05-VirtualPatch.ps1 -TargetUrl $cfg.TargetUrl -Phase Inline -ComparisonId $comparison -ConfirmAuthorizedTesting
  ```
  Match comparison ID and payload SHA-256 in local artifacts, then match the Inline PAN-OS action by UTC window, tuple, and signature.
- **TC-06:** manually establish each route phase and keep all workload values identical:
  ```powershell
  .\Tests\TC06-Performance.ps1 -TargetUrl $cfg.TargetUrl -Path $cfg.NormalPath -Phase Baseline -WarmupCount 20 -SampleCount 2000 -Concurrency 20
  .\Tests\TC06-Performance.ps1 -TargetUrl $cfg.TargetUrl -Path $cfg.NormalPath -Phase Inline -WarmupCount 20 -SampleCount 2000 -Concurrency 20
  ```
  Previous lab baseline p99 was not captured; do not attribute the historical inline p99 outlier without paired evidence.
- **TC-07:** start the monitor, then the authorized operator performs Console actions separately:
  ```powershell
  .\Tests\TC07-HAFailoverMonitor.ps1 -TargetUrl $cfg.TargetUrl -Path $cfg.HealthPath -DurationSeconds 100 -CadenceMilliseconds 300
  ```
  Press `M`/Enter for immediate markers or use the printed marker-file command from another shell. This measures interpretation A (new connections recover), not Session Resiliency. The criterion is strictly ≤5 s. Lab context remains **FAIL**: about 7 s hard interruption, 10–13 s GWLB detection, and about 50 s full-AZ end-to-end recovery.
- **TC-08:** run normal traffic and capture route/counter evidence:
  ```powershell
  .\Tests\TC08-GWLBTransparentInsertion.ps1 -TargetUrl $cfg.TargetUrl -Path $cfg.NormalPath -RequestCount 20
  ```
- **TC-09:** generate benign events, then have the SIEM operator compare the PAN-OS generated timestamp/tuple/rule/session fields with SIEM receive time:
  ```powershell
  .\Tests\TC09-SIEMLogging.ps1 -TargetUrl $cfg.TargetUrl -Path $cfg.NormalPath -EventCount 3
  ```
- **TC-10:** start monitoring before the ACM operator attaches/switches certificates and mark each action:
  ```powershell
  .\Tests\TC10-CertificateRotation.ps1 -TargetUrl $cfg.TargetUrl -Path $cfg.HealthPath -DurationSeconds 100
  ```
- **TC-11:** complete `Manual/TC11-Compliance-Checklist.md`; do not create a network criterion.
- **TC-12:** enable only customer-approved config rows, then run exactly those rows:
  ```powershell
  .\Tests\TC12-StatefulAccessControl.ps1 -TargetUrl $cfg.TargetUrl -Rows $cfg.TC12Rows
  ```
  Verify `allow-alb-to-app`, `allow-server-egress`, and `deny-all-log` as applicable by UTC window, source/destination tuple, row order, rule, and action.
- **TC-13:** approve the controlled upload path first:
  ```powershell
  .\Tests\TC13-AntiMalware.ps1 -TargetUrl $cfg.TargetUrl -Path $cfg.UploadPath -TrafficContext InboundAlb -ConfirmAuthorizedTesting
  ```
  For a separately confirmed direct-egress path, add `-ConfirmDirectEgressPath`; plain HTTP also requires `-AllowDirectHttpBaseline`. Inbound ALB HTTPS becomes backend HTTP and should be inspectable. Direct egress HTTPS may pass because there is no decryption; never report that as encrypted-body inspection.

Detailed manual checks, rollback notes, and read-only PAN-OS commands are in `Manual/AWS-PANOS-Evidence-Guide.md`.

## Results and external evidence matching

Each test creates `results\<UTC timestamp>-<run ID>-<TC>\` with `results.json`, `summary.txt`, and raw CSV when samples exist. Records include run/correlation IDs, TC/probe, UTC times, sanitized target (queries omitted), CVE/N/A, expected/observed outcomes, status/error, latency, verdict, and manual-evidence flag. Load/monitor cases add counts, distribution, p50/p95/p99, throughput, outage, gap, and markers. No response bodies, credentials, cookies, tokens, or authorization headers are logged.

Requests carry `X-EasyBuy-*` run/correlation headers, but ordinary ALB access logs and PAN-OS Traffic/Threat logs must **not** be assumed to retain arbitrary request headers. Use the field crosswalk in `Manual/AWS-PANOS-Evidence-Guide.md`: match a narrow UTC window, known Bastion/source and backend/destination tuple, target path when available, rule/session, expected signature/action, request order, and operator markers. Preserve the whole result directory plus external exports.

An exact header-value lookup is valid only when the customer has deliberately configured backend/reverse-proxy logging, a PAN-OS capture mechanism, or SIEM field extraction to retain these headers and has validated that carrier with harmless TC-01 traffic before security testing. Otherwise the IDs remain exact local/wire identifiers, not claimed ALB/PAN-OS/SIEM fields.

## Known verification gotchas

For ALB-to-backend traffic through GWLB, allow backend TCP 80 from the **ALB subnet CIDRs**, not only an ALB security-group reference. After GWLB decapsulation the SG reference may not match, leaving PAN-OS sessions `incomplete`/aged out.

On PAN-OS 11.1.15, a CLI Traffic-log command with a positional `rule equal ...` filter can show only a header even when rows exist. Run `show log traffic direction equal backward` and filter afterward, or use **Monitor > Traffic**. Useful read-only checks:

```text
show log threat direction equal backward
show log traffic direction equal backward
show counter global filter aspect pktproc | match geneve
show running security-policy
```

## CVE sources

See `CVE-REFERENCE.md`. The exact mapped vectors are backed by [NVD](https://nvd.nist.gov/), [Apache Log4j](https://logging.apache.org/log4j/2.x/security.html), [Apache Struts S2-045](https://cwiki.apache.org/confluence/display/WW/S2-045), [Red Hat Shellshock guidance](https://access.redhat.com/security/cve/cve-2014-6271), and CISA KEV links. PAN-OS IDs are lab observations pending the customer's licensed Threat Vault/log confirmation; generic signatures and EICAR remain N/A.

Content was rephrased for compliance with licensing restrictions.
