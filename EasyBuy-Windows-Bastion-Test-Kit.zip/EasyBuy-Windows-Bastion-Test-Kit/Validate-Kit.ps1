[CmdletBinding()]
param(
    [switch]$SkipChecksum
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$kitRoot = $PSScriptRoot
. (Join-Path $kitRoot 'Common\TestHelpers.ps1')

$expectedFiles = @(
    'README.md',
    'CVE-REFERENCE.md',
    'Test-Config.example.psd1',
    'VERSION.json',
    'SHA256SUMS.txt',
    'Validate-Kit.ps1',
    'Run-SelectedTests.ps1',
    'Common/TestHelpers.ps1',
    'Manual/AWS-PANOS-Evidence-Guide.md',
    'Manual/TC11-Compliance-Checklist.md',
    'Tests/TC01-PayloadVisibility.ps1',
    'Tests/TC02-Tls13.ps1',
    'Tests/TC03-ThreatPrevention.ps1',
    'Tests/TC04-FalsePositiveLoad.ps1',
    'Tests/TC05-VirtualPatch.ps1',
    'Tests/TC06-Performance.ps1',
    'Tests/TC07-HAFailoverMonitor.ps1',
    'Tests/TC08-GWLBTransparentInsertion.ps1',
    'Tests/TC09-SIEMLogging.ps1',
    'Tests/TC10-CertificateRotation.ps1',
    'Tests/TC12-StatefulAccessControl.ps1',
    'Tests/TC13-AntiMalware.ps1'
)

$failures = New-Object Collections.Generic.List[string]
foreach ($relative in $expectedFiles) {
    if (-not (Test-Path -LiteralPath (Join-Path $kitRoot $relative) -PathType Leaf)) {
        $failures.Add("Missing required file: $relative")
    }
}

# The documented quick start creates this customer-local file. It is parsed below,
# but deliberately remains outside the distributable inventory and checksums.
$allowedLocalFiles = @('Test-Config.psd1')
$actualFiles = @(Get-ChildItem -LiteralPath $kitRoot -File -Recurse | ForEach-Object {
    $_.FullName.Substring($kitRoot.Length + 1).Replace('\', '/')
} | Where-Object { $_ -notlike 'results/*' } | Sort-Object)
$unexpected = @($actualFiles | Where-Object { $expectedFiles -notcontains $_ -and $allowedLocalFiles -notcontains $_ })
foreach ($relative in $unexpected) { $failures.Add("Unexpected kit file: $relative") }

foreach ($scriptPath in @(Get-ChildItem -LiteralPath $kitRoot -File -Recurse | Where-Object { @('.ps1', '.psd1') -contains $_.Extension })) {
    $tokens = $null
    $errors = $null
    $null = [Management.Automation.Language.Parser]::ParseFile($scriptPath.FullName, [ref]$tokens, [ref]$errors)
    foreach ($parseError in @($errors)) {
        $failures.Add(('Parser error in {0}: {1}' -f $scriptPath.FullName.Substring($kitRoot.Length + 1), $parseError.Message))
    }
}

try {
    if ([string]::IsNullOrWhiteSpace($script:HelperScriptPath) -or -not (Test-Path -LiteralPath $script:HelperScriptPath)) { throw 'Defining helper path capture failed.' }
    $uri = Resolve-SafeTargetUri -TargetUrl 'https://localhost/'
    $joined = Join-SafeTargetUri -BaseUri $uri -Path '/health'
    if ($joined.AbsolutePath -ne '/health') { throw 'URI join returned the wrong path.' }
    try {
        $null = Join-SafeTargetUri -BaseUri $uri -Path 'https://other.invalid/'
        throw 'Cross-host URI guard did not reject a different host.'
    }
    catch {
        if ($_.Exception.Message -eq 'Cross-host URI guard did not reject a different host.') { throw }
    }
    $values = [double[]](1, 2, 3, 4, 100)
    if ((Get-NearestRankPercentile -Values $values -Percentile 0.50) -ne 3) { throw 'p50 self-test failed.' }
    if ((Get-NearestRankPercentile -Values $values -Percentile 0.99) -ne 100) { throw 'p99 self-test failed.' }
    $record = New-ResultRecord -Values @{ RunId='selftest'; TestCaseId='SELF'; ProbeId='SCHEMA'; CveReference=(Get-NotApplicableReference 'offline self-test') }
    foreach ($field in @('CorrelationId', 'TargetHost', 'ExpectedOutcome', 'Verdict', 'CveReference')) {
        if ($record.PSObject.Properties.Name -notcontains $field) { throw "Result schema field missing: $field" }
    }
    $probes = @(Get-SafeSecurityProbeDefinitions -MarkerId 'offline-selftest')
    if (@($probes | Where-Object { $_.CveReference -match '^CVE-' }).Count -ne 3) { throw 'CVE mapping self-test failed.' }
    if (@($probes | Where-Object { $_.Path -match '169\.254\.|etc%2Fpasswd|Runtime|getRuntime|/bin/' }).Count -ne 0) { throw 'Unsafe probe content self-test failed.' }
    $probeText = $probes | ConvertTo-Json -Depth 8
    if ($probeText -match '(?i)callback\.(?!invalid)') { throw 'A callback host is not under .invalid.' }
    $firstHash = Get-SecurityProbePayloadHash -Probe $probes[0]
    $secondHash = Get-SecurityProbePayloadHash -Probe $probes[0]
    if ($firstHash -ne $secondHash -or $firstHash -notmatch '^[0-9a-f]{64}$') { throw 'Probe hash self-test failed.' }
}
catch {
    $failures.Add('Offline helper self-test: ' + $_.Exception.Message)
}

foreach ($guarded in @('Tests/TC03-ThreatPrevention.ps1', 'Tests/TC05-VirtualPatch.ps1', 'Tests/TC13-AntiMalware.ps1')) {
    $path = Join-Path $kitRoot $guarded
    $text = Get-Content -LiteralPath $path -Raw
    if ($text -notmatch 'ConfirmAuthorizedTesting' -or $text -notmatch 'Assert-AuthorizedTesting') {
        $failures.Add("Authorization guard missing from $guarded")
    }
}

try {
    & (Join-Path $kitRoot 'Tests/TC03-ThreatPrevention.ps1') -TargetUrl 'https://localhost/'
    $failures.Add('TC-03 authorization gate did not refuse execution.')
}
catch { if ($_.Exception.Message -notmatch 'ConfirmAuthorizedTesting') { $failures.Add('TC-03 authorization gate returned the wrong error.') } }
try {
    & (Join-Path $kitRoot 'Tests/TC05-VirtualPatch.ps1') -TargetUrl 'https://localhost/' -Phase Baseline
    $failures.Add('TC-05 authorization gate did not refuse execution.')
}
catch { if ($_.Exception.Message -notmatch 'ConfirmAuthorizedTesting') { $failures.Add('TC-05 authorization gate returned the wrong error.') } }
try {
    & (Join-Path $kitRoot 'Tests/TC13-AntiMalware.ps1') -TargetUrl 'https://localhost/' -Path '/' -TrafficContext InboundAlb
    $failures.Add('TC-13 authorization gate did not refuse execution.')
}
catch { if ($_.Exception.Message -notmatch 'ConfirmAuthorizedTesting') { $failures.Add('TC-13 authorization gate returned the wrong error.') } }

$orchestratorPath = Join-Path $kitRoot 'Run-SelectedTests.ps1'
$orchestrator = Get-Content -LiteralPath $orchestratorPath -Raw
if ($orchestrator -notmatch "\[string\[\]\]\`$Tests = @\('TC01', 'TC02'\)") {
    $failures.Add('Orchestrator safe default is not exactly TC01 and TC02.')
}
try {
    & $orchestratorPath -Tests TC03 -ConfigPath (Join-Path $kitRoot 'does-not-exist.psd1')
    $failures.Add('Orchestrator authorization gate did not refuse TC-03.')
}
catch { if ($_.Exception.Message -notmatch 'ConfirmAuthorizedTesting') { $failures.Add('Orchestrator authorization gate returned the wrong error.') } }

foreach ($scriptPath in @(Get-ChildItem -LiteralPath $kitRoot -Filter '*.ps1' -File -Recurse)) {
    $text = Get-Content -LiteralPath $scriptPath.FullName -Raw
    if ($text -match '(?im)(^|[;&|]\s*)curl(\s|$)') { $failures.Add("Bare curl invocation found: $($scriptPath.Name)") }
}
if ((Get-Content -LiteralPath (Join-Path $kitRoot 'Tests/TC07-HAFailoverMonitor.ps1') -Raw) -match '(?im)^\s*(aws|terraform|az)\s+') {
    $failures.Add('TC-07 contains an infrastructure command invocation.')
}

if (-not $SkipChecksum) {
    $checksumPath = Join-Path $kitRoot 'SHA256SUMS.txt'
    if (Test-Path -LiteralPath $checksumPath) {
        $seen = New-Object Collections.Generic.List[string]
        foreach ($line in @(Get-Content -LiteralPath $checksumPath)) {
            if ($line -match '^([0-9a-fA-F]{64})  (.+)$') {
                $expected = $matches[1].ToLowerInvariant()
                $relative = $matches[2]
                $seen.Add($relative)
                $filePath = Join-Path $kitRoot $relative
                if (-not (Test-Path -LiteralPath $filePath)) {
                    $failures.Add("Checksum target missing: $relative")
                }
                else {
                    $actual = (Get-FileHash -LiteralPath $filePath -Algorithm SHA256).Hash.ToLowerInvariant()
                    if ($actual -ne $expected) { $failures.Add("Checksum mismatch: $relative") }
                }
            }
            elseif (-not [string]::IsNullOrWhiteSpace($line)) {
                $failures.Add("Malformed checksum line: $line")
            }
        }
        $manifestExpected = @($expectedFiles | Where-Object { $_ -ne 'SHA256SUMS.txt' } | Sort-Object)
        if (@($seen | Sort-Object).Count -ne $manifestExpected.Count) { $failures.Add('Checksum manifest entry count is incorrect.') }
        foreach ($relative in $manifestExpected) { if ($seen -notcontains $relative) { $failures.Add("Checksum manifest missing: $relative") } }
    }
}

if ($failures.Count -gt 0) {
    foreach ($failure in $failures) { Write-Error $failure }
    exit 1
}
Write-Host ('Kit validation passed: {0} files, parser checks, safety gates, and offline self-tests.' -f $expectedFiles.Count)
exit 0
