@{
    # Copy this file to Test-Config.psd1 and replace every placeholder.
    # This file must never contain credentials, tokens, cookies, or private keys.
    TargetUrl                  = 'https://customer-alb.example.invalid/'
    HealthPath                 = '/'
    NormalPath                 = '/'
    UploadPath                 = '/approved-upload-path'
    ExpectedCertificateDnsName = 'customer-alb.example.invalid'

    TlsAttempts                = 20
    RequestTimeoutSeconds      = 10
    NormalSampleCount          = 10000
    NormalConcurrency          = 10
    PerformanceSampleCount     = 2000
    PerformanceConcurrency     = 20
    PerformanceWarmupCount     = 20
    MonitorDurationSeconds     = 100
    MonitorCadenceMilliseconds = 300
    SiemEventCount             = 3
    TransparentRequestCount    = 20

    # TC-13: InboundAlb requires HTTPS. DirectEgress is for an operator-confirmed
    # server-egress path; plain HTTP additionally requires -AllowDirectHttpBaseline.
    AntiMalwareTrafficContext  = 'InboundAlb'

    # TC-12 sends exactly one request for each Enabled row. Keep all example rows
    # disabled until the customer supplies and approves its actual policy matrix.
    TC12Rows = @(
        @{
            Enabled         = $false
            Name            = 'approved-allow-row'
            Url             = 'https://customer-alb.example.invalid/approved-path'
            Method          = 'GET'
            ExpectedOutcome = 'ALLOW'
        }
        @{
            Enabled         = $false
            Name            = 'approved-deny-row'
            Url             = 'https://customer-alb.example.invalid/denied-path'
            Method          = 'GET'
            ExpectedOutcome = 'DENY'
        }
    )
}
