# TC-11 compliance and documentation checklist

TC-11 is manual/on-site-only. The current authoritative report says the supplied test-case list skipped TC-11 and defines no infrastructure objective. This checklist records a review without inventing a network test or PASS claim.

| Field | Customer entry |
|---|---|
| Review owner | |
| Review date/time (UTC) | |
| Reviewer(s) | |
| Applicable standard/control | |
| Artifact/document name | |
| Artifact owner/publisher | |
| Version and publication date | |
| Scope relevant to this POC | |
| Evidence location | |
| Decision (`ACCEPT`, `REJECT`, `GAP`, `NOT_APPLICABLE`) | |
| Gaps / follow-up owner / due date | |

## Review checks

- [ ] The customer has supplied the governing compliance or documentation requirement.
- [ ] The reviewed artifact and version are recorded.
- [ ] Applicability to VM-Series, GWLB, ALB/ACM, logging, and the no-decryption decision is stated only where the source supports it.
- [ ] Exceptions and evidence gaps have named owners and dates.
- [ ] No automated Bastion result is represented as proof of certification or compliance.
- [ ] Final approval is signed by the customer's authorized reviewer.

Final reviewer decision: ____________________  Date/time UTC: ____________________

Reviewer name/signature: ____________________
