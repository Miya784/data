# AWS, PAN-OS, ALB, GWLB, and SIEM evidence guide

This guide separates what the Bastion scripts measure from evidence that an authorized operator must collect. The scripts do **not** call AWS, modify PAN-OS, change routes, rotate certificates, inject failure, or query a SIEM.

## Correlation and timestamps

Every request carries `X-EasyBuy-Test-Run`, `X-EasyBuy-Test-Case`, `X-EasyBuy-Test-Probe`, and `X-EasyBuy-Correlation-ID`, and result files record UTC ISO-8601 timestamps. These headers provide exact local/wire identifiers, but ordinary ALB access logs and PAN-OS Traffic/Threat logs must **not** be assumed to retain arbitrary request headers.

Use the following fields to match external evidence. Synchronize Bastion, firewall, and SIEM clocks first, keep each test window narrow, record the known Bastion/source address, and attach exports or screenshots with the result directory.

| Evidence source | Fields to cross-check with the kit result |
|---|---|
| Bastion JSON/CSV/text | UTC start/end, target host/path/port, TC/probe, request order, local correlation ID, expected signature, operator marker |
| ALB access log, if enabled | Request timestamp, client address/port, target address/port, request path, listener/target status, processing times; do not expect `X-EasyBuy-*` fields |
| PAN-OS Traffic log | Receive/start/generated time, source/destination address and port, rule, application, action, session ID |
| PAN-OS Threat/URL log | Time, source/destination tuple, rule/session, URL path when present, threat/signature ID/name, severity, action |
| SIEM copy of PAN-OS event | PAN-OS generated/receive time, device/log type, source/destination tuple, rule/session, threat ID/action, plus SIEM receive time |
| AWS Console/GWLB/ACM evidence | Operator marker time, target/listener state, health transition, and approved change/action |

For TC-03/05/13, match the sequential probe by its tight UTC window, tuple, expected signature ID, action, and request order. For TC-09, compare the locally generated count/window with the PAN-OS event fields and then those same fields with the SIEM copy. This is evidence matching, not a claim that an arbitrary header appears in those systems.

If exact header-value lookup is required, the customer must first configure and approve a carrier that actually persists the headers—for example backend/reverse-proxy request logging, an approved PAN-OS packet/header capture, or explicit SIEM HTTP-header extraction. Validate that carrier with harmless TC-01 traffic before any security probe. Without that prerequisite, do not search for or report `X-EasyBuy-*` as an ALB/PAN-OS/SIEM log field.

PAN-OS operational commands (read-only):

```text
show log threat direction equal backward
show log traffic direction equal backward
show counter global filter aspect pktproc | match geneve
show running security-policy
```

On PAN-OS 11.1.15, `show log traffic direction equal backward rule equal <rule-name>` may return only a header even when matching rows exist. Use `show log traffic direction equal backward` and filter the output afterward, or use **Monitor > Traffic** in the GUI.

Expected rules to verify where applicable:

- `allow-alb-to-app`: client-to-ALB request after ALB TLS termination, forwarded to backend HTTP.
- `allow-server-egress`: inspected server-initiated egress.
- `deny-all-log`: policy-deny evidence for customer-approved deny rows.

## TC-specific evidence

| TC | Bastion evidence | External/manual evidence required |
|---|---|---|
| TC-01 | HTTPS status, client TLS/certificate, UTC window, local run/correlation IDs | Match the `allow-alb-to-app` flow by UTC/tuple/rule. A Traffic row alone does not prove payload inspection; use an authorized TC-03 Threat signature, approved payload capture, or a separately validated header-logging carrier when payload visibility itself must be proved. Do not call this firewall decryption. |
| TC-02 | Repeated forced TLS 1.3 attempts, certificate validation, protocol/cipher where locally available | ALB listener policy and ACM certificate association if the local runtime is limited. |
| TC-03 | One safe request, UTC time, expected signature, and CVE/N/A value per probe | Match Threat + Traffic rows by UTC/tuple/rule/session/signature/action and request order; calculate the approved ≥90% result from logs. A reset/timeout/ALB error alone is insufficient. |
| TC-04 | Raw normal samples, status distribution, p50/p95/p99, failures | Review Threat/Traffic logs for false positives, including signature 35075 if present; classify only approved business traffic. |
| TC-05 | Phase, comparison ID, payload SHA-256, UTC time, client symptom | Operator records route/policy state before each phase, changes only approved routes, restores inline state, and matches Threat/Traffic evidence for the identical payload by tuple/signature/time. |
| TC-06 | Warmup-separated Baseline/Inline samples and percentiles | Operator records route state and ALB metrics/access logs. Use identical workload settings. Prior lab baseline p99 was not captured. |
| TC-07 | ~0.3 s new-connection samples, exact markers, worst outage and gap | Operator performs authorized Console stop/force-stop/NACL/AZ action separately; capture GWLB target and ALB target transitions. This is not Session Resiliency. |
| TC-08 | Timestamped normal traffic count | Before/after GENEVE counters, route tables pointing to GWLB endpoints in both directions, and evidence ALB/app configuration did not change. |
| TC-09 | Local generation UTC/count and local correlation IDs | Match PAN-OS and SIEM copies by generated time, tuple, rule/session, action, and count; record SIEM receive timestamp, complete fields, and delay under 30 seconds. The script cannot prove delivery. |
| TC-10 | TLS continuity, thumbprint, serial, validity, and markers | ACM/listener before/after screenshots and operator change timestamp. The script never rotates the certificate. |
| TC-11 | None | Complete `TC11-Compliance-Checklist.md`; the current report defines no infrastructure test. |
| TC-12 | Exactly one request per enabled customer row | Traffic rows matched by UTC window, tuple, row order, and expected rule/action for `allow-alb-to-app`, `allow-server-egress`, or `deny-all-log`. |
| TC-13 | In-memory EICAR transfer symptom, UTC time, local correlation ID | Match Threat/Traffic rows by UTC/tuple/rule/session and IDs 39040/58073/100000 when seen. Direct egress HTTPS may pass because no egress decryption exists. |

## Operator rollback and safety notes

- TC-05: take a screenshot/export of original routes, make only the approved baseline change, and restore/verify inline routes immediately after the baseline capture. The kit never performs this action.
- TC-07: pre-approve the failure mode and rollback owner. Start the monitor first, add a marker immediately before/after the Console action, then restore the affected resource and confirm targets healthy. The strict criterion is ≤5 seconds; the recorded lab hard interruption was about 7 seconds, GWLB detection about 10–13 seconds, and full-AZ end-to-end recovery about 50 seconds, so the lab verdict remains **FAIL**.
- TC-10: attach the new ACM certificate before changing the listener default, mark the exact change, validate, then remove the prior certificate only under the customer's rollback policy.
- TC-13: use only the approved upload/egress endpoint and window. No EICAR file is written by the script.

## Network verification gotchas

The ALB must allow the Bastion source in its security group. A same-VPC Bastion can resolve or reach a public ALB differently depending on DNS, routing, and NAT; run TC-01/02 first and record source/target context.

For ALB-to-backend traffic traversing GWLB, the backend security group may need the **ALB subnet CIDRs**, not an ALB security-group reference. After GWLB decapsulation, an SG reference can fail to match and leave an `incomplete`/aged-out session even though PAN-OS allowed it.

Content was rephrased for compliance with licensing restrictions.
